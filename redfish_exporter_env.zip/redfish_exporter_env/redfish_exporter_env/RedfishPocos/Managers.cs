﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace redfish_exporter_env.RedfishPocos
{
    public class Managers
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("ManagerType")]
        public string ManagerType { get; set; }
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("ServiceEntryPointUUID")]
        public string ServiceEntryPointUUID { get; set; }
        [JsonProperty("UUID")]
        public string UUID { get; set; }
        [JsonProperty("Model")]
        public string Model { get; set; }
        [JsonProperty("DateTime")]
        public string DateTime { get; set; }
        [JsonProperty("DateTimeLocalOffset")]
        public string DateTimeLocalOffset { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("FirmwareVersion")]
        public string FirmwareVersion { get; set; }
        [JsonProperty("NetworkProtocol")]
        public Referenz NetworkProtocol { get; set; } // http://redfish.dmtf.org/redfish/v1/mockup/842#Managers--BMC--NetworkProtocol
        [JsonProperty("EthernetInterfaces")]
        public Referenz EthernetInterfaces { get; set; }
        public EthernetInterfacesManager EthernetInterfacesLookUp  { get; set;}
        [JsonProperty("SerialInterfaces")]
        public Referenz SerialInterfaces { get; set; }
        [JsonProperty("LogServices")]
        public Referenz LogServices { get; set; }
        [JsonProperty("VirtualMedia")]
        public Referenz VirtualMedia { get; set; }
        [JsonProperty("Links")]
        public Link Links { get; set; }
        [JsonProperty("Oem")]
        public OemManagers Oem { get; set; }

        public class Link
        {
            [JsonProperty("ManagerForServers")]
            public List<Referenz> ManagerForServers { get; set; }
            [JsonProperty("ManagerForChassis")]
            public List<Referenz> ManagerForChassis { get; set; }
            [JsonProperty("ManagerInChassis")]
            public Referenz ManagerInChassis { get; set; }
        }

    }
    public class EthernetInterfacesManager : Collection
    {
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("Type")]
        public string Type { get; set; }
        [JsonProperty("MemberType")]
        public string MemberType { get; set; }
        [JsonProperty("Items")]
        public List<EthernetInterfacesManagerUnit> Items { get; set; } = new List<EthernetInterfacesManagerUnit>();
    }
    public class EthernetInterfacesManagerUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("AutoNeg")]
        private bool? AutoNegB { set { Autoneg = value.ToString(); } }
        public string Autoneg { get; set; }
        [JsonProperty("Autosense")]
        private bool? Autosense { set { AutoSense = value.ToString(); } }
        public string AutoSense { get; set; }
        [JsonProperty("SpeedMbps")]
        private double? SpeedMbpsB { set { SpeedMbps = value ?? -9999; } }
        [JsonIgnore]
        public double SpeedMbps { get; set; }
        [JsonProperty("FullDuplex")]
        private bool? FullDuplexB { set { Fullduplex = value.ToString(); } }
        public string Fullduplex { get; set; }
        [JsonProperty("HostName")]
        public string HostName { get; set; }
        [JsonProperty("FQDN")]
        public string FQDN { get; set; }
        [JsonProperty("FactoryMacAddress")]
        public string FactoryMacAddress { get; set; }
        [JsonProperty("LinkTechnology")]
        public string LinkTechnology { get; set; }
        [JsonProperty("MacAddress")]
        public string MacAddress { get; set; }
        [JsonProperty("MaxIPv6StaticAddresses")]
        private double? MaxIPv6StaticAddressesB { set { MaxIPv6StaticAddresses = value ?? -9999; } }
        [JsonIgnore]
        public double MaxIPv6StaticAddresses { get; set; }
        [JsonProperty("IPv6DefaultGateway")]
        public string IPv6DefaultGateway { get; set; }
        [JsonProperty("NameServers")]
        public List<string> NameServers { get; set; }
        [JsonProperty("IPv4Addresses")]
        public List<IPv4Addresses> IPv4Addresses { get; set; } = new List<IPv4Addresses>();
        [JsonProperty("IPv6Addresses")]
        public List<IPv6Addresses> IPv6Addresses { get; set; } = new List<IPv6Addresses>();
        [JsonProperty("IPv6StaticAddresses")]
        public List<IPv6Addresses> IPv6StaticAddresses { get; set; } = new List<IPv6Addresses>();
        [JsonProperty("IPv6AddressPolicyTable")]
        public List<IPv6AddressPolicyTable> IPv6AddressPolicyTable { get; set; } = new List<IPv6AddressPolicyTable>();
    }
    public class IPv6AddressPolicyTable
    {
        [JsonProperty("Label")]
        public string Label { get; set; }
        [JsonProperty("Precedence")]
        private double? PrecedenceB { set { Precedence = value ?? -9999; } }
        [JsonIgnore]
        public double Precedence { get; set; }
        [JsonProperty("Prefix")]
        public string Prefix { get; set; }
    }
}

            