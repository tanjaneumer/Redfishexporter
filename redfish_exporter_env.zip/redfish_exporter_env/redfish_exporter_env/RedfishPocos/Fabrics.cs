﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace redfish_exporter_env.RedfishPocos
{
    public class Fabrics
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Members")]
        public List<Referenz> Members { get; set; }
    }
    public class SAS
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("FabricType")]
        public string FabricType { get; set; }
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("Zones")]
        public Referenz Zones { get; set; }
        [JsonProperty("Endpoints")]
        public Referenz Endpoints { get; set; }
        [JsonProperty("Switches")]
        public Referenz Switches { get; set; }
        [JsonProperty("links")]
        private Link Linksl { set { Links=value; } }
        [JsonProperty("Links")]
        public Link Links { get; set; }
        [JsonProperty("Oem")]
        public IDictionary<string, JToken> Oem { get; set; }
        public class Link
        {
            [JsonProperty("Oem")]
            public IDictionary<string, JToken> Oem { get; set; }
        }
    }

    public class Zones : Collection 
    {
        public List<ZonesUnit> ZonesUnit { get; set; } = new List<ZonesUnit>();
    }
    public class ZonesUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("links")]
        private Link Linksl { set { Links = value; } }
        [JsonProperty("Links")]
        public Link Links { get; set; }
        public class Link
        {
            [JsonProperty("Endpoints")]
            public List<Referenz> Endpoints { get; set; }
        }
    }
    public class Endpoints : Collection
    {
        public List<EndpointsUnit> EndpointsUnit { get; set; } = new List<EndpointsUnit>();
    }
    public class EndpointsUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("EndpointProtocol")]
        public string EndpointProtocol { get; set; }
        [JsonProperty("ConnectedEntities")]
        public List<ConnectedEntities> ConnectedEntities { get; set; } = new List<ConnectedEntities>();
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("links")]
        private Link Linksl { set { Links = value; } }
        [JsonProperty("Links")]
        public Link Links { get; set; }
        public class Link
        {
            [JsonProperty("Ports")]
            public List<Referenz> Ports { get; set; }
        }
    }
    public class ConnectedEntities
    {
        [JsonProperty("EntityType")]
        public string EntityType { get; set; }
        [JsonProperty("EntityRole")]
        public string EntityRole { get; set; }
        [JsonProperty("Identifiers")]
        public List<string> Identifiers { get; set; } = new List<string>();
    }
    public class Switches : Collection
    {
        public List<SwitchesUnit> SwitchesUnit { get; set; } = new List<SwitchesUnit>();
    }
    public class SwitchesUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("SwitchType")]
        public string SwitchType { get; set; }
        [JsonProperty("Manufacturer")]
        public string Manufacturer { get; set; }
        [JsonProperty("Model")]
        public string Model { get; set; }
        [JsonProperty("Ports")]
        public List<Referenz> Ports { get; set; }
        [JsonProperty("Redundancy")]
        public List<Redundancy> Redundancy { get; set; }
        [JsonProperty("links")]
        private Link Linksl { set { Links = value; } }
        [JsonProperty("Links")]
        public Link Links { get; set; }
        public class Link
        {
            [JsonProperty("Chassis")]
            public Referenz Chassis { get; set; }
            [JsonProperty("ManagedBy")]
            public List<Referenz> ManagedBy { get; set; }
        }
    }
}
