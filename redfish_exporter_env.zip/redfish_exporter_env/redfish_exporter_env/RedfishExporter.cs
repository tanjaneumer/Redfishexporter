﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace redfish_exporter_env
{
    public class RedfishExporter
    {
        readonly string _rootUrl;
        readonly string _redfishUser;
        readonly string _redfishUserPassword;
        readonly string _redfishRootUrl;

        public RedfishExporter(string rootUrl, string redfishUser, string redfishUserPassword, string redfishRootUrl)
        {
            _redfishRootUrl = redfishRootUrl;
            _redfishUser = redfishUser;
            _redfishUserPassword = redfishUserPassword;
            _rootUrl = rootUrl;
        }
        public void Job()
        {
            // login and save connection to logout
            var redfishConn = new RedfishRest(_rootUrl, _redfishUser, _redfishUserPassword, _redfishRootUrl);

            if (!redfishConn.success) return;
            if (redfishConn.root == null) return;

            //// convert json response to pocos
            var redfishPocos = new RedfishPoco(redfishConn);
            var chassis = redfishPocos.GetChassis(redfishConn.root.Chassis);
            var systems = redfishPocos.GetSystems(redfishConn.root.Systems);
            var managers = redfishPocos.GetManagers(redfishConn.root.Managers);

            redfishConn.Logout();

            Console.WriteLine("Start creating metrics " + DateTime.Now.ToString());
            var redfishMetric = new RedfishMetric();
            redfishMetric.Chassis(chassis);
            redfishMetric.Systems(systems);
            redfishMetric.Managers(managers);

            Console.WriteLine("End creating metrics " + DateTime.Now.ToString());
        }

        public void JobTask(object stateInfo)
        {
            Task.Factory.StartNew(() =>
            {
                Job();
            });
        }
    }
}
