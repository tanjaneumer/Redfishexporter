﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace redfish_exporter_env.RedfishPocos
{
    public class CompositionService
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("ServiceEnabled")]
        private bool? ServiceEnabledB { set { Serviceenabled = value.ToString(); } }
        public string Serviceenabled { get; set; }
        [JsonProperty("ResourceBlocks")]
        public Referenz ResourceBlocks { get; set; }
        [JsonProperty("ResourceZones")]
        public Referenz ResourceZones { get; set; }
    }
    public class ResourceBlocks : Collection
    {
        public List<ResourceBlocksUnit> ResourceBlocksUnit { get; set; }  = new List<ResourceBlocksUnit>();
    }
    public class ResourceBlocksUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("ResourceBlockType")]
        public List<string> ResourceBlockType { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("CompositionStatus")]
        private Status CompositionStatusB { get; set; }
        [JsonIgnore]
        public Status CompositionStatus
        {
            get
            {
                return CompositionStatusB ?? new Status();
            }
        }
        [JsonProperty("ComputerSystems")]
        public Referenz ComputerSystems { get; set; }
        [JsonProperty("links")]
        private List<Link> Linksl { set { Links=value; } }
        [JsonProperty("Links")]
        public List<Link> Links { get; set; }
        [JsonProperty("Oem")]
        public IDictionary<string, JToken> Oem { get; set; }
        public class Link
        {
            [JsonProperty("ComputerSystems")]
            public Referenz ComputerSystems { get; set; }
            [JsonProperty("Zones")]
            public Referenz Zones { get; set; }
        }
    }
    public class ResourceZones : Collection
    {
        public List<ResourceZonesUnit> ResourceZonesUnit { get; set; } = new List<ResourceZonesUnit>();
    }
    public class ResourceZonesUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("links")]
        private List<Link> Linksl { set { Links = value; } }
        [JsonProperty("Links")]
        public List<Link> Links { get; set; }
        [JsonProperty("Oem")]
        public IDictionary<string, JToken> Oem { get; set; }
        public class Link
        {
            [JsonProperty("ResourceBlocks")]
            public Referenz ResourceBlocks { get; set; }

        }
    }
}
