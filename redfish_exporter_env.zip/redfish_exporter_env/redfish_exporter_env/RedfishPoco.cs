﻿using redfish_exporter_env.RedfishPocos;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace redfish_exporter_env
{
    public class RedfishPoco
    {
        private readonly RedfishRest _conn;
        public RedfishPoco(RedfishRest redfishConn)
        {
            _conn = redfishConn;
        }
        public List<Chassis> GetChassis(Referenz resource)
        {
            Console.WriteLine("Collecting redfish information of chassis");

            var chassis = new List<Chassis>();
            if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
            {
                try
                {
                    var chassisColl = JsonConvert.DeserializeObject<Collection>( _conn.Response(_conn.Request(resource.OdataId)));
                    //var chassis = new List<Chassis>();

                    foreach (var item in chassisColl.Members)
                    {
                        var curr = JsonConvert.DeserializeObject<Chassis>( _conn.Response(_conn.Request(item.OdataId)));

                        resource = curr.Power;
                        if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
                        {
                            curr.PowerLookUp = JsonConvert.DeserializeObject<Power>( _conn.Response(_conn.Request(resource.OdataId)));
                        }

                        resource = curr.Thermal;
                        if (curr.Thermal != null && !string.IsNullOrEmpty(curr.Thermal.OdataId))
                        {
                            curr.ThermalLookUp = JsonConvert.DeserializeObject<Thermal>( _conn.Response(_conn.Request(resource.OdataId)));
                        }
                        // maybe more lookups needed?
                        //public class Voltages		public List<Referenz> RelatedItem { get; set; }
                        //public class Fans		    public List<Referenz> RelatedItem { get; set; }
                        //				            public List<Referenz> Redundancy { get; set; }
                        //public class Temperatures	public List<Referenz> RelatedItem { get; set; }

                        //public class Redundancy	public List<Referenz> RedundancySet { get; set; }

                        //public class Thermal		public List<Redundancy> Redundancy { get; set; }
                        //public class Power		public List<Redundancy> Redundancy { get; set; }

                        chassis.Add(curr);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine(e.Source);
                    Console.WriteLine(e.InnerException);
                    Console.WriteLine("Error occured during collecting redfish chassis");
                }
            }
            return chassis;
        }
        public List<Systems> GetSystems(Referenz resource)
        {
            Console.WriteLine("Collecting redfish information of systems");

            var systems = new List<Systems>();
            if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
            {
                try { 
                    var systemsColl = JsonConvert.DeserializeObject<Collection>( _conn.Response(_conn.Request(resource.OdataId)));
                    //var systems = new List<Systems>();

                    foreach (var item in systemsColl.Members)
                    {
                        var curr = JsonConvert.DeserializeObject<Systems>( _conn.Response(_conn.Request(item.OdataId)));
                        resource = curr.Bios;
                        if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
                        {
                            curr.BiosLookUp = JsonConvert.DeserializeObject<Bios>( _conn.Response(_conn.Request(resource.OdataId)));
                        }
                        resource = curr.Processors;
                        if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
                        {
                            curr.ProcessorsLookUp = JsonConvert.DeserializeObject<Processors>( _conn.Response(_conn.Request(resource.OdataId)));
                            foreach (var cpuItem in curr.ProcessorsLookUp.Members)
                            {
                                var cpu = JsonConvert.DeserializeObject<CPU>( _conn.Response(_conn.Request(cpuItem.OdataId)));
                                curr.ProcessorsLookUp.CPULookUp.Add(cpu);
                            }
                        }
                        else if (curr.Links.Processors != null && !string.IsNullOrEmpty(curr.Links.Processors.OdataId))
                        {
                            resource = curr.Links.Processors;
                            curr.ProcessorsLookUp = JsonConvert.DeserializeObject<Processors>( _conn.Response(_conn.Request(resource.OdataId)));
                            foreach (var cpuItem in curr.ProcessorsLookUp.Members)
                            {
                                var cpu = JsonConvert.DeserializeObject<CPU>( _conn.Response(_conn.Request(cpuItem.OdataId)));
                                curr.ProcessorsLookUp.CPULookUp.Add(cpu);
                            }
                        }

                        resource = curr.Memory;
                        if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
                        {
                            curr.MemoryLookUp = JsonConvert.DeserializeObject<Memory>( _conn.Response(_conn.Request(resource.OdataId)));
                            foreach (var memItem in curr.MemoryLookUp.Members)
                            {
                                var mem = JsonConvert.DeserializeObject<MemoryUnit>( _conn.Response(_conn.Request(memItem.OdataId)));
                                curr.MemoryLookUp.MemoryUnitLookUp.Add(mem);
                            }
                        }
                        resource = curr.EthernetInterfaces;
                        if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
                        {
                            curr.EthernetInterfacesLookUp = JsonConvert.DeserializeObject<EthernetInterfaces>( _conn.Response(_conn.Request(resource.OdataId)));
                            foreach (var ethItem in curr.EthernetInterfacesLookUp.Members)
                            {
                                var ethUnit = JsonConvert.DeserializeObject<EthernetInterfacesUnit>( _conn.Response(_conn.Request(ethItem.OdataId)));
                                if (ethUnit.VLANs != null && !string.IsNullOrEmpty(ethUnit.VLANs.OdataId))
                                {
                                    var vlan = JsonConvert.DeserializeObject<VLANs>( _conn.Response(_conn.Request(ethUnit.VLANs.OdataId)));
                                    foreach (var vlanItem in vlan.Members)
                                    {
                                        var vlanU = JsonConvert.DeserializeObject<VLANsUnit>( _conn.Response(_conn.Request(vlanItem.OdataId)));
                                        vlan.VLANsUnitLookUp.Add(vlanU);
                                    }
                                    ethUnit.VLANsLookup=vlan;
                                }
                                curr.EthernetInterfacesLookUp.EthernetInterfacesUnitLookUp.Add(ethUnit);
                            }
                        }
                        resource = curr.SimpleStorage;
                        if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
                        {
                            curr.SimpleStorageLookUp = JsonConvert.DeserializeObject<SimpleStorage>( _conn.Response(_conn.Request(resource.OdataId)));
                            foreach (var sstorItem in curr.SimpleStorageLookUp.Members)
                            {
                                var sstor = JsonConvert.DeserializeObject<SimpleStorageUnit>( _conn.Response(_conn.Request(sstorItem.OdataId)));
                                curr.SimpleStorageLookUp.SimpleStorageUnitLookUp.Add(sstor);
                            }
                        }
                        resource = curr.LogServices;
                        if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
                        {
                            curr.LogServicesLookUp = JsonConvert.DeserializeObject<LogServices>( _conn.Response(_conn.Request(resource.OdataId)));
                            foreach (var servItem in curr.LogServicesLookUp.Members)
                            {
                                var serv = JsonConvert.DeserializeObject<LogServicesUnit>( _conn.Response(_conn.Request(servItem.OdataId)));
                                if (serv.Entries != null && !string.IsNullOrEmpty(serv.Entries.OdataId))
                                {
                                    serv.EntriesLookUp = JsonConvert.DeserializeObject<Entries>( _conn.Response(_conn.Request(serv.Entries.OdataId)));
                                }
                                curr.LogServicesLookUp.LogServicesUnitLookUp.Add(serv);
                            }
                        }
                        // test if it is HP
                        resource = curr.Oem?.Hp?.Links?.SmartStorage;
                        if (!string.IsNullOrEmpty(resource?.OdataId))
                        {
                            curr.Oem.Hp.SmartStorageLookup = JsonConvert.DeserializeObject<OemHp.SmartStorage>( _conn.Response(_conn.Request(resource.OdataId)));
                            resource = curr.Oem.Hp.SmartStorageLookup?.Links?.ArrayControllers;
                            if (!string.IsNullOrEmpty(resource?.OdataId))
                            {
                                curr.Oem.Hp.SmartStorageLookup.ArrayControllers =
                                    JsonConvert.DeserializeObject<OemHp.ArrayControllers>( _conn.Response(_conn.Request(resource.OdataId)));
                                foreach (var oemItem in curr.Oem.Hp.SmartStorageLookup.ArrayControllers.Members)
                                {
                                    var arrC = JsonConvert.DeserializeObject<OemHp.ArrayControllersUnit>( _conn.Response(_conn.Request(oemItem.OdataId)));
                                    resource = arrC?.Links?.LogicalDrives;
                                    if (!string.IsNullOrEmpty(resource?.OdataId))
                                    {
                                        arrC.LogicalDrivesLookUp = JsonConvert.DeserializeObject<OemHp.LogicalDrives>( _conn.Response(_conn.Request(resource.OdataId)));
                                        foreach (var drivItem in arrC.LogicalDrivesLookUp.Members)
                                        {
                                            var drive = JsonConvert.DeserializeObject<OemHp.LogicalDrivesUnit>( _conn.Response(_conn.Request(drivItem.OdataId)));
                                            arrC.LogicalDrivesLookUp.LogicalDrivesUnitLookUp.Add(drive);
                                        }
                                    }
                                    resource = arrC?.Links?.PhysicalDrives;
                                    if (!string.IsNullOrEmpty(resource?.OdataId))
                                    {
                                        if (resource.OdataId.Contains("DiskDrive"))
                                        {
                                            arrC.DiskDrivesLookUp = JsonConvert.DeserializeObject<OemHp.DiskDrives>( _conn.Response(_conn.Request(resource.OdataId)));
                                            foreach (var drivItem in arrC.DiskDrivesLookUp.Members)
                                            {
                                                var drive = JsonConvert.DeserializeObject<OemHp.DiskDrivesUnit>( _conn.Response(_conn.Request(drivItem.OdataId)));
                                                arrC.DiskDrivesLookUp.DiskDrivesUnitLookUp.Add(drive);
                                            }
                                        }
                                    }
                                    curr.Oem.Hp.SmartStorageLookup.ArrayControllers.ArrayControllersUnitLookup.Add(arrC);
                                }
                            }
                        }

                        systems.Add(curr);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine(e.Source);
                    Console.WriteLine(e.InnerException);
                    Console.WriteLine("Error occured during collecting redfish systems");
                }
            }
            return systems;
        }

        public List<Managers> GetManagers(Referenz resource)
        {
            Console.WriteLine("Collecting redfish information of managers");

            var managers = new List<Managers>();
            if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
            {
                try
                { 
                    var manColl = JsonConvert.DeserializeObject<Collection>( _conn.Response(_conn.Request(resource.OdataId)));
                    foreach (var item in manColl.Members)
                    {
                        var curr = JsonConvert.DeserializeObject<Managers>( _conn.Response(_conn.Request(item.OdataId)));
                        resource = curr.EthernetInterfaces;
                        if (resource != null && !string.IsNullOrEmpty(resource.OdataId))
                        {
                            curr.EthernetInterfacesLookUp = JsonConvert.DeserializeObject<EthernetInterfacesManager>( _conn.Response(_conn.Request(resource.OdataId)));
                        }
                        managers.Add(curr);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    Console.WriteLine(e.Source);
                    Console.WriteLine(e.InnerException);
                    Console.WriteLine("Error occured during collecting redfish managers poco");
                }
            }
            return managers;
        }
    }
}
