﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace redfish_exporter_env.RedfishPocos
{
    public class Chassis
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("ChassisType")]
        public string ChassisType { get; set; }
        [JsonProperty("Manufacturer")]
        public string Manufacturer { get; set; }
        [JsonProperty("Model")]
        public string Model { get; set; }        
        [JsonProperty("SKU")]
        public string SKU { get; set; }
        [JsonProperty("SerialNumber")]
        public string SerialNumber { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("PhysicalSecurity")]
        public PhysicalSecurity PhysicalSecurity { get; set; }
        public Power PowerLookUp { get; set; }
        [JsonProperty("Power")]
        public Referenz Power { get; set; }
        [JsonProperty("Thermal")]
        public Referenz Thermal { get; set; }
        public Thermal ThermalLookUp { get; set; }
        [JsonProperty("links")]
        public ReferenzLinks Links { get; set; }
    }

    public class PhysicalSecurity
    {
        [JsonProperty("IntrusionSensor")]
        public string IntrusionSensor { get; set; }
        [JsonProperty("IntrusionSensorNumber")]
        public double? IntrusionSensorNumber { get; set; }
        [JsonProperty("IntrusionSensorReArm")]
        public string IntrusionSensorReArm { get; set; }

    }
    public class Thermal
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Temperatures")]
        public List<Temperatures> Temperatures { get; set; }
        [JsonProperty("Fans")]
        public List<Fans> Fans { get; set; }
        [JsonProperty("Redundancy")]
        public List<Redundancy> Redundancy { get; set; }
    }

    public class Temperatures
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Number")]
        private string Number { set { Id = value; } }
        [JsonProperty("MemberID")]
        private string MemberId { set { Id = value; } }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("ReadingCelsius")]
        public double? ReadingCelsius { get; set; } 
        [JsonProperty("UpperThresholdCritical")]
        public double? UpperThresholdCritical { get; set; } 
        [JsonProperty("UpperThresholdFatal")]
        public double? UpperThresholdFatal { get; set; }
        [JsonProperty("LowerThresholdCritical")]
        public double? LowerThresholdCritical { get; set; }
        [JsonProperty("LowerThresholdFatal")]
        public double? LowerThresholdFatal { get; set; }
        [JsonProperty("MinReadingRange")]
        public double? MinReadingRange { get; set; }
        [JsonProperty("MaxReadingRange")]
        public double? MaxReadingRange { get; set; }
        [JsonProperty("PhysicalContext")]
        public string PhysicalContext { get; set; }
        [JsonProperty("Units")]
        public string Units { get; set; }
        [JsonProperty("RelatedItem")]
        public List<Referenz> RelatedItem { get; set; }
    }

    public class Fans
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("MemberID")]
        private string MemberId { set { Id = value; } }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("FanName")]
        private string FanName { set { Name = value; } }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("CurrentReading")]
        private double? CurrentReading { set { Reading = value; } }
        [JsonProperty("Reading")]
        public double? Reading { get; set; }
        [JsonProperty("Units")]
        private string Units { set { ReadingUnits = value; } }
        [JsonProperty("ReadingUnits")]
        public string ReadingUnits { get; set; }
        [JsonProperty("LowerThresholdCritical")]
        public double? LowerThresholdCritical { get; set; }
        [JsonProperty("LowerThresholdFatal")]
        public double? LowerThresholdFatal { get; set; }
        [JsonProperty("UpperThresholdCritical")]
        public double? UpperThresholdCritical { get; set; }
        [JsonProperty("UpperThresholdFatal")]
        public double? UpperThresholdFatal { get; set; }
        //[JsonProperty("MinReadingRange")]
        //public double? MinReadingRange { get; set; }
        //[JsonProperty("MaxReadingRange")]
        //public double? MaxReadingRange { get; set; }
        [JsonProperty("RelatedItem")]
        public List<Referenz> RelatedItem { get; set; }
        [JsonProperty("Redundancy")]
        public List<Referenz> Redundancy { get; set; }
    }

    public class Redundancy
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("RedundancySet")]
        public List<Referenz> RedundancySet { get; set; }
        [JsonProperty("Mode")]
        public string Mode { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("MinNumNeeded")]
        public double? MinNumNeeded { get; set; }
        [JsonProperty("MaxNumSupported")]
        public double? MaxNumSupported { get; set; }
        [JsonProperty("MemberID")]
        public string MemberId { set { Id = value; } }
    }

    public class Power
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("MemberID")]
        private string MemberId { set { Id = value; } }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("PowerControl")]
        public List<PowerControl> PowerControl { get; set; } = new List<RedfishPocos.PowerControl>();
        [JsonProperty("Voltages")]
        public List<Voltages> Voltages { get; set; } = new List<RedfishPocos.Voltages>();
        [JsonProperty("PowerSupplies")]
        public List<PowerSupplies> PowerSupplies { get; set; } = new List<RedfishPocos.PowerSupplies>();
        [JsonProperty("Redundancy")]
        public List<Redundancy> Redundancy { get; set; } = new List<RedfishPocos.Redundancy>();
    }

    public class Voltages
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("SensorNumber")]
        public double? SensorNumber { get; set; } 
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("ReadingVolts")]
        public double? ReadingVolts { get; set; }
        [JsonProperty("UpperThresholdNonCritical")]
        public double? UpperThresholdNonCritical { get; set; }
        [JsonProperty("UpperThresholdCritical")]
        public double? UpperThresholdCritical { get; set; }
        [JsonProperty("UpperThresholdFatal")]
        public double? UpperThresholdFatal { get; set; }
        [JsonProperty("LowerThresholdNonCritical")]
        public double? LowerThresholdNonCritical { get; set; }
        [JsonProperty("LowerThresholdCritical")]
        public double? LowerThresholdCritical { get; set; }
        [JsonProperty("LowerThresholdFatal")]
        public double? LowerThresholdFatal { get; set; }
        [JsonProperty("MinReadingRange")]
        public double? MinReadingRange { get; set; }
        [JsonProperty("MaxReadingRange")]
        public double? MaxReadingRange { get; set; }
        [JsonProperty("PhysicalContext")]
        public string PhysicalContext { get; set; }
        [JsonProperty("RelatedItem")]
        public List<Referenz> RelatedItem { get; set; }

    }

    public class PowerControl
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("MemberID")]
        private string MemberId { set { Id = value; } }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("PowerLimit")]
        public PowerLimit PowerLimit { get; set; }
        [JsonProperty("PowerConsumedWatts")]
        public double? PowerConsumedWatts { get; set; }
        [JsonProperty("PowerAvailableWatts")]
        public double? PowerAvailableWatts { get; set; } //PowerAvailableWatts ==  powerCapacity - powerAllocated
        [JsonProperty("PowerAllocatedWatts")]
        public double? PowerAllocatedWatts { get; set; }
        [JsonProperty("PowerMetrics")]
        public PowerMetrics PowerMetrics { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status {
            get {
                return StatusB?? new Status();
            }
        }
    }

    public class PowerMetrics
    {
        [JsonProperty("AverageConsumedWatts")]
        public double? AverageConsumedWatts { get; set; }
        [JsonProperty("IntervalInMin")]
        public double? IntervalInMin { get; set; }
        [JsonProperty("MaxConsumedWatts")]
        public double? MaxConsumedWatts { get; set; }
        [JsonProperty("MinConsumedWatts")]
        public double? MinConsumedWatts { get; set; }
        [JsonProperty("PowerConsumedWatts")]
        public double? PowerConsumedWatts { get; set; }
        [JsonProperty("PowerCapacityWatts")]
        public double? PowerCapacityWatts { get; set; } //PowerAvailableWatts ==  powerCapacity - powerAllocated
        [JsonProperty("PowerAllocatedWatts")]
        public double? PowerAllocatedWatts { get; set; } //  total amount of power that has been allocated (or budegeted)to chassis resources.
    }

    public class PowerLimit
    {
        [JsonProperty("LimitInWatts")]
        public double? LimitInWatts { get; set; }
        [JsonProperty("LimitException")]
        public string LimitException { get; set; }
        [JsonProperty("CorrectionInMs")]
        public double? CorrectionInMs { get; set; }
    }

    public class PowerSupplies
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("MemberID")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("PowerSupplyType")]
        public string PowerSupplyType { get; set; }
        [JsonProperty("LineInputVoltageType")]
        public string LineInputVoltageType { get; set; }
        [JsonProperty("LineInputVoltage")]
        public double? LineInputVoltage { get; set; }
        [JsonProperty("PowerCapacityWatts")]
        public double? PowerCapacityWatts { get; set; }
        [JsonProperty("LastPowerOutputWatts")]
        public double? LastPowerOutputWatts { get; set; }
        [JsonProperty("Model")]
        public string Model { get; set; }
        [JsonProperty("Manufacturer")]
        public string Manufacturer { get; set; }
        [JsonProperty("FirmwareVersion")]
        public string FirmwareVersion { get; set; }
        [JsonProperty("SerialNumber")]
        public string SerialNumber { get; set; }
        [JsonProperty("PartNumber")]
        public string PartNumber { get; set; }
        [JsonProperty("SparePartNumber")]
        public string SparePartNumber { get; set; }
        [JsonProperty("InputRanges")]
        public List<InputRanges> InputRanges { get; set; }
    }
    public class InputRanges
    {
        [JsonProperty("InputType")]
        public string InputType { get; set; }
        [JsonProperty("MinimumVoltage")]
        public double? MinimumVoltage { get; set; }
        [JsonProperty("MaximumVoltage")]
        public double? MaximumVoltage { get; set; }
        [JsonProperty("OutputWattage")]
        public double? OutputWattage { get; set; }
    }
}
