﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Linq;
using System.Threading.Tasks;
using redfish_exporter_env.RedfishPocos;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace redfish_exporter_env
{
    public class RedfishRest
    {
        readonly RestClient _client;
        readonly string _logoutResource;
        readonly string _url;
        public readonly Root root;
        public readonly bool success = false;

        public RedfishRest(string baseUrl, string username, string password, string redfishRootUrl)
        {
            _client = new RestClient(baseUrl);
            var response = new RestResponse();

            Task.Run(async () =>
            {
                response = await GetResponseContentAsync(_client, new RestRequest(redfishRootUrl)) as RestResponse;
            }).Wait();

            if (response.ResponseStatus != ResponseStatus.Completed || !string.IsNullOrEmpty(response.ErrorMessage) || response.ErrorException != null)
            {
                Console.WriteLine("Error reading Redfish root");
                return;
            }

            root = JsonConvert.DeserializeObject<Root>(response.Content);

            _url = baseUrl;
            _client = new RestClient(baseUrl);
            _client.AddDefaultHeader("Content-Type", "application/json;charset=UTF-8");
            _client.AddDefaultHeader("Accept", "application/json;charset=UTF-8");
            _client.AddDefaultHeader("Cache", "no-cache");


            _logoutResource = Login(redfishRootUrl,username, password);
            if (!string.IsNullOrEmpty(_logoutResource)) success = true;

        }

        // https://www.learnhowtoprogram.com/net/apis-67c53b46-d070-4d2a-a264-cf23ee1d76d0/apis-with-mvc
        public static Task<IRestResponse> GetResponseContentAsync(RestClient theClient, RestRequest theRequest)
        {
            var tcs = new TaskCompletionSource<IRestResponse>();
            theClient.ExecuteAsync(theRequest, response => {
                tcs.SetResult(response);
            });
            return tcs.Task;
        }

        private string Login (string redfishRootUrl, string username, string password)
        {
            Console.WriteLine(DateTime.Now.ToString()+": starting redfish session with " + _url);
            var req = new RestRequest(redfishRootUrl + "SessionService/Sessions/", Method.POST);
            req.AddJsonBody(new
            {
                UserName = username,
                Password = password
            });

            var response = new RestResponse();

            Task.Run(async () =>
            {
                response = await GetResponseContentAsync(_client, req) as RestResponse;
            }).Wait();

            if (response.ResponseStatus != ResponseStatus.Completed || !string.IsNullOrEmpty(response.ErrorMessage) || response.ErrorException != null)
            {
                Console.WriteLine("error connecting to " + _url + redfishRootUrl);
                return null;
            }
            if(response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                Console.WriteLine("unauthorized user for " + _url + redfishRootUrl);
                return null;
            }
            if (response.StatusCode != System.Net.HttpStatusCode.Created)
            {
                Console.WriteLine("error connecting to " + _url + redfishRootUrl);
                Console.WriteLine("Http Status Code " + response.StatusCode.ToString());
                Console.WriteLine("Response " + response.Content);
                return null;
            }

            Console.WriteLine("connection succeeded");

            // Set Session Header Parameters
            string headerkey, headervalue;
            headerkey = "X-Auth-Token";
            headervalue = response.Headers.First(para => para.Name == headerkey)?.Value.ToString();
            if (!string.IsNullOrEmpty(headervalue)) _client.AddDefaultHeader(headerkey, headervalue);
            else Console.WriteLine("error connecting: no x-auth field for session in response");

            headerkey = "Location";
            headervalue = response.Headers.First(para => para.Name == headerkey)?.Value.ToString();
            string logoutResource = "";
            if (!string.IsNullOrEmpty(headervalue)) logoutResource = headervalue.Replace(_url, "");
            else Console.WriteLine("error connecting: no location field for session in response");

            return logoutResource;
        }

        public void Logout()
        {
            RestRequest req;
            if (!string.IsNullOrEmpty(_logoutResource)) req = new RestRequest(_logoutResource, Method.DELETE);
            else req =new RestRequest(Method.DELETE);

            _client.ExecuteAsync(req, response => {
                if (response.StatusCode != System.Net.HttpStatusCode.OK || string.IsNullOrEmpty(response.ErrorMessage) && response.ErrorException == null)
                {
                    Console.WriteLine(DateTime.Now.ToString() + ": ended redfish session with " + _url + " successfully");
                }
                else Console.WriteLine("error ending session");
            });
        }


        public RestRequest Request(string resource)
        {
            return new RestRequest(resource, Method.GET);
        }
       

        public string Response(RestRequest req)
        {
            //// For debugging
            //var requestToLog = new
            //{
            //    parameters = request.Parameters.Select(parameter => new
            //    {
            //        name = parameter.Name,
            //        value = parameter.Value,
            //        type = parameter.Type.ToString()
            //    }),
            //    uri = _client.BuildUri(request),
            //};
            //Console.WriteLine(string.Format("Request: {0},", JsonConvert.SerializeObject(requestToLog)));

           //var response =  _client.Execute(request);
           var response = new RestResponse();

            Task.Run(async () =>
            {
                response = await GetResponseContentAsync(_client, req) as RestResponse;
            }).Wait();

            //// For debugging
            //Console.WriteLine("Response URI: " + response.ResponseUri);
            //Console.WriteLine("Response Status: " + response.ResponseStatus);
            //Console.WriteLine("Response StatusCode: " + response.StatusCode);
            //Console.WriteLine("Response StatusDescription: " + response.StatusDescription);
            //Console.WriteLine("Headers: ");
            //foreach (var item in response.Headers)
            //{
            //    Console.WriteLine("  " + item.Name + ": " + item.Value.ToString());
            //}
            //Console.WriteLine("Content:");
            //Console.WriteLine(response.Content);

            return response.Content;
        }
    }
}
