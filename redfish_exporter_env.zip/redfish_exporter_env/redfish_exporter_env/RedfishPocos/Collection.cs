﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace redfish_exporter_env.RedfishPocos
{
    public class Root
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("RedfishVersion")]
        public string RedfishVersion { get; set; }
        [JsonProperty("Chassis")]
        public Referenz Chassis { get; set; }
        [JsonProperty("Systems")]
        public Referenz Systems { get; set; }
        [JsonProperty("Managers")]
        public Referenz Managers { get; set; }
        [JsonProperty("Fabrics")]
        public Referenz Fabrics { get; set; }
        [JsonProperty("CompositionService")]
        public Referenz CompositionService { get; set; }
        [JsonProperty("Time")]
        public string Time { get; set; }
    }

    public class Referenz
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("href")]
        private string Href { set { OdataId = value; } }
    }

    public class ReferenzLinks
    {
        [JsonProperty("Chassis")]
        public List<Referenz> Chassis { get; set; } = new List<Referenz>();
        [JsonProperty("ComputerSystems")]
        public List<Referenz> ComputerSystems { get; set; } = new List<Referenz>();
        [JsonProperty("ManagedBy")]
        public List<Referenz> ManagedBy { get; set; } = new List<Referenz>();
        [JsonProperty("ResourceBlocks")]
        public List<Referenz> ResourceBlocks { get; set; } = new List<Referenz>();
        [JsonProperty("Contains")]
        public List<Referenz> Contains { get; set; } = new List<Referenz>();
        [JsonProperty("EthernetInterfaces")]
        public Referenz EthernetInterfaces { get; set; }
        [JsonProperty("Logs")]
        public Referenz Logs { get; set; }
        [JsonProperty("Processors")]
        public Referenz Processors { get; set; }
    }

    public class Status
    {
        [JsonProperty("State")]
        public string State { get; set; } = "";
        [JsonProperty("Health")]
        public string Health { get; set; } = "";
        [JsonProperty("HealthRollup")]
        public string HealthRollup { get; set; } = "";
        public double HealthVal
        {
            get
            {
                return (!string.IsNullOrEmpty(Health) ? Health : HealthRollup).ToStatus();
            }
        }
        public double StateMetric
        {
            get
            {
                return (string.IsNullOrEmpty(State)) ? -1 : State.ToState();
            }
        }
    }

    public class Collection
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Members")]
        public List<Referenz> Members { get; set; } = new List<Referenz>();
    }

    public class OemSystems
    {
        [JsonProperty("Hp")]
        public OemHp.Systems Hp { get; set; }
    }
    public class OemManagers
    {
        [JsonProperty("Hp")]
        public OemHp.Managers Hp { get; set; }
    }
}