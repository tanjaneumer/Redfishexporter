﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using redfish_exporter_env.RedfishPocos;
using Newtonsoft.Json;
using Prometheus;
using System.IO;
using System.Threading;
using Microsoft.Extensions.Configuration;

namespace redfish_exporter_env
{
    class Program
    {
        private static readonly AutoResetEvent _closing = new AutoResetEvent(false);
        private static Task _redfish;
        private static bool _run = true;


        static void Main(string[] args)
        {

            var envs = EnvCheck();
            MainRedfish(envs);
        }
        static string[] EnvCheck()
        {
            Console.OutputEncoding = Encoding.UTF8;
            string[] envs = new string[6];
            string str, env;

            str = "PORT";
            env = Environment.GetEnvironmentVariable(str);
            if (String.IsNullOrWhiteSpace(env))
                throw new ArgumentNullException("\nEnvironment variable " + str + " is missing. Please enter the port at which the exporter metrics will be accessible\n");
            else
            {
                bool testPort = double.TryParse(env, out double port);
                if (!testPort)
                {
                    throw new ArgumentNullException("\nPlease enter a numeric argument for port for the exporter\n");
                }
            }
            envs[5] = env;

            str = "HOST_IP";
            env = Environment.GetEnvironmentVariable(str);
            if (String.IsNullOrWhiteSpace(env))
                throw new ArgumentNullException("\nEnvironment variable " + str + " is missing. Please enter the IPv4 address to the redfish manager device\n");
            else
            {
                bool testIp = IPAddress.TryParse(env, out IPAddress ip);
                if (!testIp)
                {
                    throw new ArgumentNullException("\nPlease enter a valid IPv4 address\n");
                }
            }
            envs[0] = env;

            str = "VERSION_AS_INTEGER";
            env = Environment.GetEnvironmentVariable(str);
            if (String.IsNullOrWhiteSpace(env))
                throw new ArgumentNullException("\nEnvironment variable " + str + " is missing. Please enter the redfish version as integer e.g. 1 for redfish/v1/ as root url\n");
            else
            {
                bool testIp = IPAddress.TryParse(env, out IPAddress ip);
                if (!testIp)
                {
                    throw new ArgumentNullException("\nPlease enter a valid integer for the redfish version\n");
                }
            }
            envs[1] = env;

            str = "USER";
            env = Environment.GetEnvironmentVariable(str);
            if (String.IsNullOrWhiteSpace(env))
                throw new ArgumentNullException("\nEnvironment variable " + str + " is missing. Please enter the redfish user account name\n");
            envs[2] = env;

            str = "PASSWORD";
            env = Environment.GetEnvironmentVariable(str);
            if (String.IsNullOrWhiteSpace(env))
                throw new ArgumentNullException("\nEnvironment variable " + str + " is missing. Please enter the redfish user account password\n");
            envs[3] = env;

            str = "PERIOD";
            env = Environment.GetEnvironmentVariable(str);
            if (String.IsNullOrWhiteSpace(env))
            {
                Console.WriteLine("\nEnvironment variable " + str + " is not set. The time period in which the information from redfish will be fetched is set to 20 seconds\n");
                envs[4] = "20";
            }
            else
            {
                bool testInterval = double.TryParse(env, out double interval);
                if (!testInterval)
                {
                    throw new ArgumentNullException("\nPlease enter a numeric argument for the period in which redfish information are fetched\n");
                }
                if (interval < 10)
                {
                    throw new ArgumentNullException("\nThe value for the period is less than 10 seconds. The period must be at least 10 seconds.\n");
                }
                envs[4] = env;
            }

            return envs;
        }

        protected static void MainRedfish(string[] args)
        {

            ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;

            Console.WriteLine("\nPress crtl + c to stop the app\n");

            string rootUrl = "https://" + args[0];
            string redfishRootUrl = "/redfish/v" + args[1] + "/";
            string redfishUser = args[2];
            string redfishUserPassword = args[3];
            int redfishPeriod = int.Parse(args[4]);
            int port = int.Parse(args[5]);

            Console.WriteLine("Starting Redfish-Exporter " + DateTime.Now.ToString());
            Console.WriteLine("Connection url:" + rootUrl + redfishRootUrl);
            Console.WriteLine("Expose metrics at port 9393");
            Console.WriteLine("Fetch information every " + redfishPeriod.ToString() + " seconds\n");

            var metricServer = new MetricServer(port);
            metricServer.Start();

            _redfish = Task.Factory.StartNew(() =>
            {
                while (_run)
                {
                    new RedfishExporter(rootUrl, redfishUser, redfishUserPassword, redfishRootUrl).Job();
                    if (_run) Thread.Sleep(redfishPeriod * 1000);
                }
            });

            Console.CancelKeyPress += new ConsoleCancelEventHandler(OnExit);
            _closing.WaitOne();

            metricServer.Stop();
            Console.WriteLine("\nEnded Redfish-Exporter " + DateTime.Now.ToString());
        }

        protected static void OnExit(object sender, ConsoleCancelEventArgs args)
        {
            Console.WriteLine("\nEnding Redfish-Exporter. Please wait... This may take some seconds.\n");
            _run = false;
            _redfish.Wait();
            _closing.Set();
        }
    }
}
