﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace redfish_exporter_env.RedfishPocos
{
    public class Systems
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("SystemType")]
        public string SystemType { get; set; }
        [JsonProperty("AssetType")]
        public string AssetType { get; set; }
        [JsonProperty("Manufacturer")]
        public string Manufacturer { get; set; }
        [JsonProperty("SKU")]
        public string SKU { get; set; }
        [JsonProperty("SerialNumber")]
        public string SerialNumber { get; set; }
        [JsonProperty("PartNumber")]
        public string PartNumber { get; set; }
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("HostName")]
        public string HostName { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("IndicatorLED")]
        public string IndicatorLED { get; set; }
        [JsonProperty("PowerState")]
        public string PowerState { get; set; }
        //[JsonProperty("Boot")]
        //public BootSystem Boot { get; set; }
        [JsonProperty("TrustedModules")]
        public List<TrustedModulesSystem> TrustedModules { get; set; } = new List<TrustedModulesSystem>();
        [JsonProperty("Oem")]
        public OemSystems Oem { get; set; }
        [JsonProperty("BiosVersion")]
        public string BiosVersion { get; set; }
        [JsonProperty("Bios")]
        public Referenz Bios { get; set; }
        public Bios BiosLookUp { get; set; }
        [JsonProperty("ProcessorSummary")]
        public ProcessorSummary ProcessorSummary { get; set; }
        [JsonProperty("Processors")]
        public Referenz Processors { get; set; }
        public Processors ProcessorsLookUp { get; set; }
        [JsonProperty("MemorySummary")]
        public MemorySummary MemorySummary { get; set; }
        [JsonProperty("Memory")]
        public Referenz Memory { get; set; }
        public Memory MemoryLookUp { get; set; }
        [JsonProperty("EthernetInterfaces")]
        public Referenz EthernetInterfaces { get; set; }
        public EthernetInterfaces EthernetInterfacesLookUp { get; set; }
        [JsonProperty("Storage")]
        public Referenz Storage { get; set; }
        public Storage StorageLookUp { get; set; }
        [JsonProperty("SimpleStorage")]
        public Referenz SimpleStorage { get; set; }
        public SimpleStorage SimpleStorageLookUp { get; set; }
        [JsonProperty("LogServices")]
        public Referenz LogServices { get; set; }
        public LogServices LogServicesLookUp { get; set; }
        [JsonProperty("Links")]
        public ReferenzLinks Links { get; set; }
    }

    //public class BootSystem
    //{
    //    [JsonProperty("BootSourceOverrideEnabled")]
    //    public string BootSourceOverrideEnabled { get; set; }
    //    [JsonProperty("BootSourceOverrideTarget")]
    //    public string BootSourceOverrideTarget { get; set; }
    //    [JsonProperty("BootSourceOverrideMode")]
    //    public string BootSourceOverrideMode { get; set; }
    //    [JsonProperty("UefiTargetBootSourceOverride")]
    //    public string UefiTargetBootSourceOverride { get; set; }
    //}

    public class TrustedModulesSystem
    {
        [JsonProperty("FirmwareVersion")]
        public string FirmwareVersion { get; set; }
        [JsonProperty("InterfaceType")]
        public string InterfaceType { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
    }

    public class ProcessorSummary
    {
        [JsonProperty("Count")]
        public double? Count { get; set; }
        [JsonProperty("Model")]
        public string Model { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
    }
    public class MemorySummary
    {
        [JsonProperty("TotalSystemMemoryGiB")]
        public double? TotalSystemMemoryGiB { get; set; }
        [JsonProperty("Model")]
        public string Model { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
    }
    public class Bios
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("AttributeRegistry")]
        public string AttributeRegistry { get; set; }
        [JsonProperty("Attributes")]
        public Attributes Attributes { get; set; }
    }

    public class Attributes {
        [JsonProperty("AdminPhone")]
        public string AdminPhone { get; set; }
        [JsonProperty("BootMode")]
        public string BootMode { get; set; }
        [JsonProperty("EmbeddedSata")]
        public string EmbeddedSata { get; set; }
        [JsonProperty("NicBoot1")]
        public string NicBoot1 { get; set; }
        [JsonProperty("NicBoot2")]
        public string NicBoot2 { get; set; }
        [JsonProperty("PowerProfile")]
        public string PowerProfile { get; set; }
        [JsonProperty("ProcCoreDisable")]
        public double? ProcCoreDisable { get; set; }
        [JsonProperty("ProcHyperthreading")]
        public string ProcHyperthreading { get; set; }
        [JsonProperty("ProcTurboMode")]
        public string ProcTurboMode { get; set; }
        [JsonProperty("UsbControl")]
        public string UsbControl { get; set; }
    }

    public class Processors : Collection
    {
        public List<CPU> CPULookUp { get; set; } = new List<CPU>();
    }
    public class CPU
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Socket")]
        public string Socket { get; set; }
        [JsonProperty("ProcessorType")]
        public string ProcessorType { get; set; }
        [JsonProperty("ProcessorArchitecture")]
        public string ProcessorArchitecture { get; set; }
        [JsonProperty("InstructionSet")]
        public string InstructionSet { get; set; }
        [JsonProperty("Manufacturer")]
        public string Manufacturer { get; set; }
        [JsonProperty("Model")]
        public string Model { get; set; }
        [JsonProperty("ProcessorId")]
        public ProcessorId ProcessorId { get; set; }
        [JsonProperty("MaxSpeedMHz")]
        public double? MaxSpeedMHz { get; set; }
        [JsonProperty("TotalCores")]
        public double? TotalCores { get; set; }
        [JsonProperty("TotalThreads")]
        public double? TotalThreads { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
    }
    public class ProcessorId
    {
        [JsonProperty("VendorId")]
        public string VendorId { get; set; }
        [JsonProperty("IdentificationRegisters")]
        public string IdentificationRegisters { get; set; }
        [JsonProperty("EffectiveFamily")]
        public string EffectiveFamily { get; set; }
        [JsonProperty("EffectiveModel")]
        public string EffectiveModel { get; set; }
        [JsonProperty("Step")]
        public string Step { get; set; }
        [JsonProperty("MicrocodeInfo")]
        public string MicrocodeInfo { get; set; }
    }

    public class Memory : Collection
    {
        public List<MemoryUnit> MemoryUnitLookUp { get; set; } = new List<MemoryUnit>();
    }
    public class MemoryUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("RankCount")]
        public double? RankCount { get; set; } 
        [JsonProperty("MaxTDPMilliWatts")]
        public List<int> MaxTDPMilliWatts { get; set; } = new List<int>();
        [JsonProperty("CapacityMiB")]
        public double? CapacityMiB { get; set; }
        [JsonProperty("DataWidthBits")]
        public double? DataWidthBits { get; set; }
        [JsonProperty("BusWidthBits")]
        public double? BusWidthBits { get; set; }
        [JsonProperty("ErrorCorrection")]
        public string ErrorCorrection { get; set; }
        [JsonProperty("MemoryLocation")]
        public MemoryLocation MemoryLocation { get; set; }
        [JsonProperty("MemoryType")]
        public string MemoryType { get; set; }
        [JsonProperty("MemoryDeviceType")]
        public string MemoryDeviceType { get; set; }
        [JsonProperty("BaseModuleType")]
        public string BaseModuleType { get; set; }
        [JsonProperty("MemoryMedia")]
        public List<string> MemoryMedia { get; set; } = new List<string>();
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
    }
    public class MemoryLocation {
        [JsonProperty("Socket")]
        public double? Socket { get; set; }
        [JsonProperty("MemoryController")]
        public double? MemoryController { get; set; } 
        [JsonProperty("Channel")]
        public double? Channel { get; set; }
        [JsonProperty("Slot")]
        public double? Slot { get; set; } 
    }
    public class EthernetInterfaces : Collection
    {
        public List<EthernetInterfacesUnit> EthernetInterfacesUnitLookUp { get; set; } = new List<EthernetInterfacesUnit>();
    }
    public class EthernetInterfacesUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Id")]
        public string Id { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("PermanentMACAddress")]
        public string PermanentMACAddress { get; set; }
        [JsonProperty("MACAddress")]
        public string MACAddress { get; set; }
        [JsonProperty("SpeedMbps")]
        public double? SpeedMbps { get; set; }
        [JsonProperty("MTUSize")]
        public double? MTUSize { get; set; }
        [JsonProperty("AutoNeg")]
        public bool? AutoNeg { get; set; }
        [JsonProperty("FullDuplex")]
        public bool? FullDuplex { get; set; }
        [JsonProperty("HostName")]
        public string HostName { get; set; }
        [JsonProperty("FQDN")]
        public string FQDN { get; set; }
        [JsonProperty("IPv6DefaultGateway")]
        public string IPv6DefaultGateway { get; set; }
        [JsonProperty("NameServers")]
        public List<string> NameServers { get; set; }
        [JsonProperty("IPv4Addresses")]
        public List<IPv4Addresses> IPv4Addresses { get; set; } = new List<IPv4Addresses>();
        [JsonProperty("IPv6Addresses")]
        public List<IPv6Addresses> IPv6Addresses { get; set; } = new List<IPv6Addresses>();
        [JsonProperty("VLANs")]
        public Referenz VLANs { get; set; }
        public VLANs VLANsLookup { get; set; }
        [JsonProperty("VLAN")]
        public VLAN VLAN { get; set; }
    }

    public class IPv4Addresses
    {
        [JsonProperty("Address")]
        public string Address { get; set; }
        [JsonProperty("SubnetMask")]
        public string SubnetMask { get; set; }
        [JsonProperty("AddressOrigin")]
        public string AddressOrigin { get; set; }
        [JsonProperty("Gateway")]
        public string Gateway { get; set; }
    }
    public class IPv6Addresses
    {
        [JsonProperty("Address")]
        public string Address { get; set; }
        [JsonProperty("PrefixLength")]
        public double? PrefixLength { get; set; }
        [JsonProperty("AddressOrigin")]
        public string AddressOrigin { get; set; }
        [JsonProperty("AddressState")]
        public string AddressState { get; set; }
    }
    public class VLAN
    {
        [JsonProperty("Name")]
        public string Name { get; set; } = "";
        [JsonProperty("VLANEnable")]
        public bool? VLANEnable { get; set; }
        [JsonProperty("VLANId")]
        public double? VLANId { get; set; } 
    }
    public class VLANs : Collection
    {
        public List<VLANsUnit> VLANsUnitLookUp { get; set; } = new List<VLANsUnit>();
    }
    public class VLANsUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; } = "";
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("VLANEnable")]
        public bool? VLANEnable { get; set; }
        [JsonProperty("VLANId")]
        public double? VLANId { get; set; }
    }

    public class Storage {  }
    public class SimpleStorage : Collection
    {
        public List<SimpleStorageUnit> SimpleStorageUnitLookUp { get; set; } = new List<SimpleStorageUnit>();
    }
    public class SimpleStorageUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Description")]
        public string Description { get; set; }
        [JsonProperty("UefiDevicePath")]
        public string UefiDevicePath { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
        [JsonProperty("Devices")]
        public List<Devices> Devices { get; set; } = new List<Devices>();
    }

    public class Devices
    {
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("Manufacturer")]
        public string Manufacturer { get; set; }
        [JsonProperty("Model")]
        public string Model { get; set; }
        [JsonProperty("CapacityBytes")]
        public string CapacityBytes { get; set; }
        [JsonProperty("Status")]
        private Status StatusB { get; set; }
        [JsonIgnore]
        public Status Status
        {
            get
            {
                return StatusB ?? new Status();
            }
        }
    }

    public class LogServices : Collection
    {
        public List<LogServicesUnit> LogServicesUnitLookUp { get; set; } = new List<LogServicesUnit>();

    }
    public class LogServicesUnit
    {
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("MaxNumberOfRecords")]
        public double? MaxNumberOfRecords { get; set; }
        [JsonProperty("OverWritePolicy")]
        public string OverWritePolicy { get; set; }
        [JsonProperty("DateTime")]
        public string DateTime { get; set; }
        [JsonProperty("DateTimeLocalOffset")]
        public string DateTimeLocalOffset { get; set; }
        [JsonProperty("Entries")]
        public Referenz Entries { get; set; }
        public Entries EntriesLookUp { get; set; }
    }
    public class Entries : Collection
    {
        // todo http://redfish.dmtf.org/redfish/v1/mockup/841#Systems--437XR1138R2--LogServices
        // todo http://redfish.dmtf.org/redfish/v1/mockup/841#Systems--437XR1138R2--LogServices--Log1
        // todo http://redfish.dmtf.org/redfish/v1/mockup/841#Systems--437XR1138R2--LogServices--Log1--Entries
        [JsonProperty("Items")]
        public List<EntriesUnit> Items { get; set; }
    }
public class EntriesUnit
{
        [JsonProperty("@odata.id")]
        public string OdataId { get; set; }
        [JsonProperty("Name")]
        public string Name { get; set; }
        [JsonProperty("EntryType")]
        public string EntryType { get; set; }
        [JsonProperty("OemRecordFormat")]
        public string OemRecordFormat { get; set; }
        [JsonProperty("RecordId")]
        public double? RecordId { get; set; }
        [JsonProperty("Severity")]
        public string Severity { get; set; }
        [JsonProperty("Created")]
        public string Created { get; set; }
        [JsonProperty("EntryCode")]
        public string EntryCode { get; set; }
        [JsonProperty("SensorType")]
        public string SensorType { get; set; }
        [JsonProperty("Number")]
        public double? Number { get; set; }
        [JsonProperty("Message")]
        public string Message { get; set; }
        [JsonProperty("MessageID")]
        public string MessageID { get; set; }
        [JsonProperty("MessageArgs")]
        public List<string> MessageArgs { get; set; }
        [JsonProperty("Links")]
        public Link Links { get; set; }
        public class Link
        {
            [JsonProperty("OriginOfCondition")]
            public Referenz OriginOfCondition { get; set; }
        }
    }
}