﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace redfish_exporter_env.RedfishPocos
{
    public class OemHp
    {
 
        // System OEMs
        public class Systems
        {
            [JsonProperty("@odata.id")]
            public string OdataId { get; set; }
            [JsonProperty("Name")]
            public string Name { get; set; }
            [JsonProperty("HostOS")]
            public HpOs HostOS { get; set; }
            [JsonProperty("Battery")]
            public List<Battery> Batteries { get; set; }
            [JsonProperty("links")]
            public ReferenzLinks Links { get; set; }
            public SmartStorage SmartStorageLookup { get; set; }
        }
        public class SmartStorage
        {
            [JsonProperty("@odata.id")]
            public string OdataId { get; set; }
            [JsonProperty("Name")]
            public string Name { get; set; }
            [JsonProperty("Status")]
            private Status StatusB { get; set; }
            [JsonIgnore]
            public Status Status
            {
                get
                {
                    return StatusB ?? new Status();
                }
            }
            [JsonProperty("links")]
            public SmartStorageLinks Links { get; set; }
            public ArrayControllers ArrayControllers { get; set; }

            public class SmartStorageLinks
            {
                [JsonProperty("ArrayControllers")]
                public Referenz ArrayControllers { get; set; }
                [JsonProperty("HostBusAdapters")]
                public Referenz HostBusAdapters { get; set; }
            }
        }
        public class ArrayControllers : Collection
        {
            public List<ArrayControllersUnit> ArrayControllersUnitLookup { get; set; } = new List<ArrayControllersUnit>();
        }
        public class ArrayControllersUnit
        {
            [JsonProperty("@odata.id")]
            public string OdataId { get; set; }
            [JsonProperty("Id")]
            public string Id { get; set; }
            [JsonProperty("Name")]
            public string Name { get; set; }
            [JsonProperty("BackupPowerSourceStatus")]
            public string BackupPowerSourceStatus { get; set; }
            [JsonProperty("CacheMemorySizeMiB")]
            public double? CacheMemorySizeMiB { get; set; }
            [JsonProperty("CurrentOperatingMode")] // RAID for instance
            public string CurrentOperatingMode { get; set; }
            [JsonProperty("InternalPortCount")]
            public double? InternalPortCount { get; set; } 
            [JsonProperty("Model")]
            public string Model { get; set; }
            [JsonProperty("Status")]
            private Status StatusB { get; set; }
            [JsonIgnore]
            public Status Status
            {
                get
                {
                    return StatusB ?? new Status();
                }
            }
            public ArrayLinks Links { get; set; }
            // lookups
            public LogicalDrives LogicalDrivesLookUp { get; set; }
            public DiskDrives DiskDrivesLookUp { get; set; }
            public class ArrayLinks
            {
                [JsonProperty("LogicalDrives")]
                public Referenz LogicalDrives { get; set; }
                [JsonProperty("PhysicalDrives")]
                public Referenz PhysicalDrives { get; set; }
                [JsonProperty("StorageEnclosures")]
                public Referenz StorageEnclosures { get; set; }
                [JsonProperty("UnconfiguredDrives")]
                public Referenz UnconfiguredDrives { get; set; }
            }
        }
        public class LogicalDrives : Collection
        {
            public List<LogicalDrivesUnit> LogicalDrivesUnitLookUp { get; set; } = new List<LogicalDrivesUnit>();
        }
        public class LogicalDrivesUnit
        {
            [JsonProperty("@odata.id")]
            public string OdataId { get; set; }
            [JsonProperty("Id")]
            public string Id { get; set; }
            [JsonProperty("CapacityMiB")]
            public double? CapacityMiB { get; set; } 
            [JsonProperty("StripeSizeBytes")]
            public double? StripeSizeBytes { get; set; } 
            [JsonProperty("LogicalDriveName")]
            public string LogicalDriveName { get; set; }
            [JsonProperty("LogicalDriveNumber")]
            public double? LogicalDriveNumber { get; set; } 
            [JsonProperty("LogicalDriveType")]
            public string LogicalDriveType { get; set; }
            [JsonProperty("Name")]
            public string Name { get; set; }
            [JsonProperty("Raid")]
            public double? Raid { get; set; } 
            [JsonProperty("VolumeUniqueIdentifier")]
            public string VolumeUniqueIdentifier { get; set; }
            [JsonProperty("Status")]
            private Status StatusB { get; set; }
            [JsonIgnore]
            public Status Status
            {
                get
                {
                    return StatusB ?? new Status();
                }
            }
        }
        public class DiskDrives : Collection
        {
            public List<DiskDrivesUnit> DiskDrivesUnitLookUp { get; set; } = new List<DiskDrivesUnit>();
        }
        public class DiskDrivesUnit
        {
            [JsonProperty("@odata.id")]
            public string OdataId { get; set; }
            [JsonProperty("Name")]
            public string Name { get; set; }
            [JsonProperty("BlockSizeBytes")]
            public double? BlockSizeBytes { get; set; } 
            [JsonProperty("CapacityGB")]
            public double? CapacityGB { get; set; } 
            [JsonProperty("CapacityLogicalBlocks")]
            public double? CapacityLogicalBlocks { get; set; } 
            [JsonProperty("CapacityMiB")]
            public double? CapacityMiB { get; set; } 
            [JsonProperty("CarrierApplicationVersion")]
            public string CarrierApplicationVersion { get; set; }
            [JsonProperty("CarrierAuthenticationStatus")]
            public string CarrierAuthenticationStatus { get; set; }
            [JsonProperty("CurrentTemperatureCelsius")]
            public double? CurrentTemperatureCelsius { get; set; } 
            [JsonProperty("DiskDriveStatusReasons")]
            public List<string> DiskDriveStatusReasons { get; set; }
            [JsonProperty("InterfaceSpeedMbps")]
            public double? InterfaceSpeedMbps { get; set; } 
            [JsonProperty("Location")]
            public string Location { get; set; }
            [JsonProperty("MaximumTemperatureCelsius")]
            public double? MaximumTemperatureCelsius { get; set; } 
            [JsonProperty("MediaType")]
            public string MediaType { get; set; }
            [JsonProperty("PowerOnHours")]
            public double? PowerOnHours { get; set; } 
            [JsonProperty("RotationalSpeedRpm")]
            public double? RotationalSpeedRpm { get; set; } 
            [JsonProperty("SSDEnduranceUtilizationPercentage")]
            public double? SSDEnduranceUtilizationPercentage { get; set; } 
            [JsonProperty("Status")]
            private Status StatusB { get; set; }
            [JsonIgnore]
            public Status Status
            {
                get
                {
                    return StatusB ?? new Status();
                }
            }
        }

        public class HpOs
        {
            [JsonProperty("OsName")]
            public string OsName { get; set; }
            [JsonProperty("OsType")]
            public double? OsType { get; set; } 
            [JsonProperty("OsVersion")]
            public string OsVersion { get; set; }
        }
        public class Battery
        {
            [JsonProperty("Condition")]
            public string Condition { get; set; }
            [JsonProperty("ErrorCode")]
            public double? ErrorCode { get; set; } 
            [JsonProperty("FirmwareVersion")]
            public string FirmwareVersion { get; set; }
            [JsonProperty("Index")]
            public double? Index { get; set; } 
            [JsonProperty("MaxCapWatts")]
            public double? MaxCapWatts { get; set; } 
            [JsonProperty("Model")]
            public string Model { get; set; }
            [JsonProperty("Present")]
            public string Present { get; set; }
            [JsonProperty("ProductName")]
            public string ProductName { get; set; }
            [JsonProperty("SerialNumber")]
            public string SerialNumber { get; set; }
            [JsonProperty("Spare")]
            public string Spare { get; set; }
        }
        public class ReferenzLinks
        {
            [JsonProperty("BIOS")]
            public Referenz BIOS { get; set; }
            [JsonProperty("EthernetInterfaces")]
            public Referenz EthernetInterfaces { get; set; }
            [JsonProperty("FirmwareInventory")]
            public Referenz FirmwareInventory { get; set; }
            [JsonProperty("Memory")]
            public Referenz Memory { get; set; }
            [JsonProperty("NetworkAdapters")]
            public Referenz NetworkAdapters { get; set; }
            [JsonProperty("PCIDevices")]
            public Referenz PCIDevices { get; set; }
            [JsonProperty("PCISlots")]
            public Referenz PCISlots { get; set; }
            [JsonProperty("SmartStorage")]
            public Referenz SmartStorage { get; set; }
            [JsonProperty("SoftwareInventory")]
            public Referenz SoftwareInventory { get; set; }
        }

        // Manager OEM
        public class Managers
        {
            [JsonProperty("iLOSelfTestResults")]
            public List<IloSelfTestResultsUnit> IloSelfTestResults { get; set; } = new List<IloSelfTestResultsUnit>();
        }
        public class IloSelfTestResultsUnit
        {
            [JsonProperty("Notes")]
            public string Notes { get; set; }
            [JsonProperty("SelfTestName")]
            public string SelfTestName { get; set; }
            [JsonProperty("Status")]
            private string Status { get; set; }
        }
    }
}
