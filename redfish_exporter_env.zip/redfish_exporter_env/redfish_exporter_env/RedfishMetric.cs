﻿using Prometheus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using redfish_exporter_env.RedfishPocos;

namespace redfish_exporter_env
{
    public class RedfishMetric
    {

        private const string _app = "redfish";


       // private readonly Gauge _up;

        // system
        private readonly Gauge _system_health;
        private readonly Gauge _system_state;
        private readonly Gauge _system_power_state;
        private readonly Gauge _system_processors_health; 
        private readonly Gauge _system_processors_state;
        private readonly Gauge _system_processor_health;
        private readonly Gauge _system_processor_state;
        private readonly Gauge _system_memories_health;
        private readonly Gauge _system_memories_state;
        private readonly Gauge _system_ethernet_interface_health;
        private readonly Gauge _system_ethernet_interface_state;
        private readonly Gauge _system_ethernet_interface_speed;
        private readonly Gauge _system_ethernet_interface_vlan;
        private readonly Gauge _system_storage_health;
        private readonly Gauge _system_storage_state;
        private readonly Gauge _system_storage_battery_health;
        private readonly Gauge _system_storage_array_ctrl_health;
        private readonly Gauge _system_storage_array_ctrl_state;
        private readonly Gauge _system_storage_logical_drive_health;
        private readonly Gauge _system_storage_logical_drive_state;
        private readonly Gauge _system_storage_disk_drive_health;
        private readonly Gauge _system_storage_disk_drive_state;
        private readonly Gauge _system_storage_disk_drive_temperature;
        private readonly Gauge _system_storage_disk_drive_temperature_max;
        private readonly Gauge _system_storage_ssd_endurance_utilization;
        private readonly Gauge _system_storage_carrier_authentication_status ;
        private readonly Gauge _system_storage_rotational_speed_rpm;
        private readonly Gauge _system_simplestorage_health;
        private readonly Gauge _system_simplestorage_state;

        // chassis
        private readonly Gauge _chassis_state;
        private readonly Gauge _chassis_health;
        private readonly Gauge _chassis_power_control_state;
        private readonly Gauge _chassis_power_control_health;
        private readonly Gauge _chassis_power_control_consumed_watts;
        private readonly Gauge _chassis_power_control_avg_consumed_watts;
        private readonly Gauge _chassis_power_control_min_consumed_watts;
        private readonly Gauge _chassis_power_control_max_consumed_watts;
        private readonly Gauge _chassis_power_supplies_state;
        private readonly Gauge _chassis_power_supplies_health;
        private readonly Gauge _chassis_power_redundancy;
        private readonly Gauge _chassis_power_supplies_input_voltage;
        private readonly Gauge _chassis_computer_systems;
        private readonly Gauge _chassis_temp_state;
        private readonly Gauge _chassis_temp_health;
        private readonly Gauge _chassis_temp;
        private readonly Gauge _chassis_temp_critical_low;
        private readonly Gauge _chassis_temp_fatal_low;
        private readonly Gauge _chassis_temp_critical_up;
        private readonly Gauge _chassis_temp_fatal_up;
        private readonly Gauge _chassis_fan_state;
        private readonly Gauge _chassis_fan_health;
        private readonly Gauge _chassis_fan_reading;
        private readonly Gauge _chassis_fan_reading_critical_low;
        private readonly Gauge _chassis_fan_reading_fatal_low;
        private readonly Gauge _chassis_fan_reading_critical_up;
        private readonly Gauge _chassis_fan_reading_fatal_up;
        private readonly Gauge _chassis_voltage_state;
        private readonly Gauge _chassis_voltage_health;
        private readonly Gauge _chassis_voltage_reading;
        private readonly Gauge _chassis_voltage_reading_critical_low;
        private readonly Gauge _chassis_voltage_reading_fatal_low;
        private readonly Gauge _chassis_voltage_reading_critical_up;
        private readonly Gauge _chassis_voltage_reading_fatal_up;
        private readonly Gauge _chassis_intrusion;

        // managers
        private readonly Gauge _manager_state;
        private readonly Gauge _manager_health;
        private readonly Gauge _manager_eth_interface_speed;
        private readonly Gauge _manager_links;

        public RedfishMetric()
        {
            // die Gauges
           // _up = Metrics.CreateGauge(_app+"connection_to_root", "redfish connection to root works", "redfishHost", "rootUrl");

            // system
            _system_health
                = Metrics.CreateGauge(_app+"_system_health", "system itself and system with children,  ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system");
            _system_state
                = Metrics.CreateGauge(_app + "_system_state", "system itself and system with children, absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system");
            _system_power_state
                = Metrics.CreateGauge(_app + "_system_power_state", "power state of system, 1 is healty/on", "hostname", "system", "type", "powerState");
            _system_processors_health
                = Metrics.CreateGauge(_app + "_system_processors_health", "system processors overall health,  ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system", "model");
            _system_processors_state
                = Metrics.CreateGauge(_app + "_system_processors_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system", "model");
            _system_processor_health
                = Metrics.CreateGauge(_app + "_system_processor_health", "health for each processor,  ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system", "processor", "type");
            _system_processor_state
                = Metrics.CreateGauge(_app + "_system_processor_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system", "processor", "type");
            _system_memories_health
                = Metrics.CreateGauge(_app + "_system_memories_health", "system memories overall health,  ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system", "model", "totalMemGiB");
            _system_memories_state
                = Metrics.CreateGauge(_app + "_system_memories_state", " absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system", "model", "totalMemGiB");
            _system_ethernet_interface_health =
                Metrics.CreateGauge(_app + "_system_ethernet_interface_health", "ethernet interface health, ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system", "eth", "mac");
            _system_ethernet_interface_state =
                Metrics.CreateGauge(_app + "_system_ethernet_interface_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system", "eth", "mac");
            _system_ethernet_interface_speed =
                Metrics.CreateGauge(_app + "_system_ethernet_interface_speed", "current speed in Mbps of this interface", "hostname", "system", "eth", "ips", "autoneg", "fullduplex", "mtuSize");
            _system_ethernet_interface_vlan =
                Metrics.CreateGauge(_app + "_system_ethernet_interface_vlan", "vlan enabled on interface: true(1), false(0), unknown(-1)", "hostname", "system", "eth", "vlan", "vlanname");
            _system_storage_health =
                Metrics.CreateGauge(_app + "_system_storage_health", "storage health, ok(1), warning(0.5), critical(0), unknown(-1), vlan enabled on interface: true(1), false(0), unknown(-1)", "hostname", "system", "os");
            _system_storage_state =
                Metrics.CreateGauge(_app + "_system_storage_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1), vlan enabled on interface: true(1), false(0), unknown(-1)", "hostname", "system", "os");
            _system_storage_battery_health =
                Metrics.CreateGauge(_app + "_system_storage_battery_health", "1 is healty, condition label is used to determine health", "hostname", "system", "errorcode", "index", "present", "condition");
            _system_storage_array_ctrl_health =
                Metrics.CreateGauge(_app + "_system_storage_array_ctrl_health", "health of array controller, ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system", "arrctrl", "backuppower", "operatingmode");
            _system_storage_array_ctrl_state =
                Metrics.CreateGauge(_app + "_system_storage_array_ctrl_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system", "arrctrl", "backuppower", "operatingmode");
            _system_storage_logical_drive_health =
                Metrics.CreateGauge(_app + "_system_storage_logical_drive_health", "health of logical drive, ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system", "arrctrl", "logicaldrive", "logicaldrivenr", "logicaldrivetype", "raidlevel");
            _system_storage_logical_drive_state =
                Metrics.CreateGauge(_app + "_system_storage_logical_drive_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system", "arrctrl", "logicaldrive", "logicaldrivenr", "logicaldrivetype", "raidlevel");
            _system_storage_disk_drive_health =
                Metrics.CreateGauge(_app + "_system_storage_disk_drive_health", "health of disk drive, ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system", "arrctrl", "diskdrive", "diskdrivestatusreasons");
            _system_storage_disk_drive_state =
                Metrics.CreateGauge(_app + "_system_storage_disk_drive_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system", "arrctrl", "diskdrive", "diskdrivestatusreasons");
            _system_storage_disk_drive_temperature =
               Metrics.CreateGauge(_app + "_system_storage_disk_drive_temperature", "current temperatue in celsius", "hostname", "system", "arrctrl", "diskdrive");
            _system_storage_disk_drive_temperature_max =
                Metrics.CreateGauge(_app + "_system_storage_disk_drive_temperature_max", "maximal recommended temperatue in celsius", "hostname", "system", "arrctrl", "diskdrive");
            _system_storage_ssd_endurance_utilization =
               Metrics.CreateGauge(_app + "_system_storage_ssd_endurance_utilization", "percentage of the drive that has been worn out and can no longer be used, 100 means completely worn out", "hostname", "system", "arrctrl", "diskdrive");
            _system_storage_carrier_authentication_status =
               Metrics.CreateGauge(_app + "_system_storage_carrier_authentication_status", "authentication status of the drive carrier", "hostname", "system", "arrctrl", "diskdrive");
            _system_storage_rotational_speed_rpm =
               Metrics.CreateGauge(_app + "_system_storage_rotational_speed_rpm", "rotational speed in rpm", "hostname", "system", "arrctrl", "diskdrive", "mediatype");
            _system_simplestorage_health =
                Metrics.CreateGauge(_app + "_system_simplestorage_health", "simple storage health, ok(1), warning(0.5), critical(0), unknown(-1)", "hostname", "system", "storage");
            _system_simplestorage_state =
                Metrics.CreateGauge(_app + "_system_simplestorage_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "hostname", "system", "storage");

            // chassis
            _chassis_health
                = Metrics.CreateGauge(_app + "_chassis_health", "health of chassis, ok(1), warning(0.5), critical(0), unknown(-1)", "chassis", "type");
            _chassis_state
                = Metrics.CreateGauge(_app + "_chassis_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "chassis", "type");
            _chassis_power_redundancy
                = Metrics.CreateGauge(_app + "_chassis_power_redundancy", "true(1), false(0)", "chassis", "mode", "members");
            _chassis_computer_systems
                = Metrics.CreateGauge(_app + "_chassis_computer_systems", "computer systems associated with chassis, 1 means there are computer systems associated", "chassis", "members");
            _chassis_power_control_health
                = Metrics.CreateGauge(_app + "_chassis_power_control_health", "health of power control, ok(1), warning(0.5), critical(0), unknown(-1)", "chassis", "control", "controlId");
            _chassis_power_control_state
                = Metrics.CreateGauge(_app + "_chassis_power_control_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "chassis", "control", "controlId");
            _chassis_power_control_consumed_watts
               = Metrics.CreateGauge(_app + "_chassis_power_control_consumed_watts", "current value of consumed watts", "chassis", "control","controlId");
            _chassis_power_control_avg_consumed_watts
              = Metrics.CreateGauge(_app + "_chassis_power_control_avg_consumed_watts", "average in given interval, also min and max values", "chassis", "control", "controlId", "intervallinmin");
            _chassis_power_control_min_consumed_watts
              = Metrics.CreateGauge(_app + "_chassis_power_control_min_consumed_watts", "minimum in given interval, also min and max values", "chassis", "control", "controlId", "intervallinmin");
            _chassis_power_control_max_consumed_watts
              = Metrics.CreateGauge(_app + "_chassis_power_control_max_consumed_watts", "maximum in given interval, also min and max values", "chassis", "control", "controlId", "intervallinmin");
            _chassis_power_supplies_health
                = Metrics.CreateGauge(_app + "_chassis_power_supplies_health", "health of power supply, ok(1), warning(0.5), critical(0), unknown(-1)", "chassis", "supply", "supplyId");
            _chassis_power_supplies_state
                = Metrics.CreateGauge(_app + "_chassis_power_supplies_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "chassis", "supply", "supplyId");
            _chassis_power_supplies_input_voltage
               = Metrics.CreateGauge(_app + "_chassis_power_supplies_input_voltage", "input voltage of power supply", "chassis", "supply", "supplyId", "minRange", "maxRange");
            _chassis_temp_health
                = Metrics.CreateGauge(_app + "_chassis_temp_health", "temperature health, ok(1), warning(0.5), critical(0), unknown(-1), related context listed", "chassis", "temp", "tempId", "physicalcontext", "related");
            _chassis_temp_state
                = Metrics.CreateGauge(_app + "_chassis_temp_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1), related context listed", "chassis", "temp", "tempId", "physicalcontext", "related");
            _chassis_temp
               = Metrics.CreateGauge(_app + "_chassis_temp", "temperatures by device with thresholds", "chassis", "temp", "tempId");
            _chassis_temp_critical_low
                = Metrics.CreateGauge(_app + "_chassis_temp_critical_low", "min critical temperatures by device with thresholds", "chassis", "temp", "tempId");
            _chassis_temp_fatal_low
                = Metrics.CreateGauge(_app + "_chassis_temp_fatal_low", "min fatal temperatures by device with thresholds", "chassis", "temp", "tempId");
            _chassis_temp_critical_up
                = Metrics.CreateGauge(_app + "_chassis_temp_critical_up", "max critical temperatures by device with thresholds", "chassis", "temp", "tempId");
            _chassis_temp_fatal_up
                = Metrics.CreateGauge(_app + "_chassis_temp_fatal_up", "max fatal temperatures by device", "chassis", "temp", "tempId");
            _chassis_fan_health
                = Metrics.CreateGauge(_app + "_chassis_fan_health", "state of fan, ok(1), warning(0.5), critical(0), unknown(-1)", "chassis", "fan", "fanId", "related");
            _chassis_fan_state
                = Metrics.CreateGauge(_app + "_chassis_fan_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "chassis", "fan", "fanId", "related");
            _chassis_fan_reading
                = Metrics.CreateGauge(_app + "_chassis_fan_reading", "current speed in percentage", "chassis", "fan", "fanId");
            _chassis_fan_reading_critical_low
                = Metrics.CreateGauge(_app + "_chassis_fan_reading_critical_low", "min critical speed in percentage", "chassis", "fan", "fanId");
            _chassis_fan_reading_fatal_low
                = Metrics.CreateGauge(_app + "_chassis_fan_reading_fatal_low", "min fatal speed in percentage", "chassis", "fan", "fanId");
            _chassis_fan_reading_critical_up
                = Metrics.CreateGauge(_app + "_chassis_fan_reading_critical_up", "max critical speed in percentage", "chassis", "fan", "fanId");
            _chassis_fan_reading_fatal_up
                = Metrics.CreateGauge(_app + "_chassis_fan_reading_fatal_up", "max fatal speed in percentage", "chassis", "fan", "fanId");
            _chassis_voltage_health
                = Metrics.CreateGauge(_app + "_chassis_voltage_health", "voltage health, ok(1), warning(0.5), critical(0), unknown(-1), related context shown", "chassis", "voltage", "voltageId", "physicalcontext", "related");
            _chassis_voltage_state
                = Metrics.CreateGauge(_app + "_chassis_voltage_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1), related context shown", "chassis", "voltage", "voltageId", "physicalcontext", "related");
            _chassis_voltage_reading
                = Metrics.CreateGauge(_app + "_chassis_voltage_reading", "voltage in Volt by device with thresholds", "chassis", "voltage", "voltageId");
            _chassis_voltage_reading_critical_low
                = Metrics.CreateGauge(_app + "_chassis_voltage_reading_critical_low", "min critical voltage in Volt by device with thresholds", "chassis", "voltage", "voltageId");
            _chassis_voltage_reading_fatal_low
                = Metrics.CreateGauge(_app + "_chassis_voltage_reading_fatal_low", "min fatal voltage in Volt by device with thresholds", "chassis", "voltage", "voltageId");
            _chassis_voltage_reading_critical_up
                = Metrics.CreateGauge(_app + "_chassis_voltage_reading_critical_up", "max critical voltage in Volt by device with thresholds", "chassis", "voltage", "voltageId");
            _chassis_voltage_reading_fatal_up
                = Metrics.CreateGauge(_app + "_chassis_voltage_reading_fatal_up", "max fatal voltage in Volt by device with thresholds", "chassis", "voltage", "voltageId");
            _chassis_intrusion
                = Metrics.CreateGauge(_app + "_chassis_intrusion", " state of the physical security sensor, normal(1), hardwareintrusion(2), tamperingdetected(3), unkown(-1)", "chassis", "sensorNumber");
            // managers
            _manager_health
                = Metrics.CreateGauge(_app + "_manager_health", "manager health, ok(1), warning(0.5), critical(0), unknown(-1)", "manager", "type");
            _manager_state
                = Metrics.CreateGauge(_app + "_manager_state", "state: absent (0), enabled (1), standby (2), starting/testing/updating (3), disables/deferring/unavailableoffline (4), unknown (-1)", "manager", "type");
            _manager_eth_interface_speed
               = Metrics.CreateGauge(_app + "_manager_eth_interface_speed", "in Mbps", "manager", "eth", "mac", "host","autoneg","fullduplex");
            _manager_links
               = Metrics.CreateGauge(_app + "_manager_links", "1 means there are related item", "manager", "systems", "chassis");
        }

        public void Chassis(List<Chassis> chassis)
        {
            foreach (var chas in chassis)
            {
                //general
                try
                {
                    chas.Id = Helper.createId(chas.Id, chas.Name);
                    var status = chas.Status.ToMetric();
                    _chassis_health.Labels(chas.Id, chas.ChassisType).Set(status.HealthVal);
                    _chassis_state.Labels(chas.Id, chas.ChassisType).Set(status.StateMetric);
                    if (chas.Links != null) _chassis_computer_systems.Labels(chas.Id, String.Join(", ", chas.Links.ComputerSystems.Select(it => it.OdataId.ToMetric()))).Set((chas.Links.ComputerSystems.Count > 0) ? 1 : 0);
                }
                catch(Exception e)
                {
                    Console.WriteLine("Exception during creating chassis health metric: " + e.Message);
                }
                
                try
                {
                    if (chas.PhysicalSecurity != null)
                    {
                        _chassis_intrusion.Labels(chas.Id, chas.PhysicalSecurity.IntrusionSensorNumber.ToMetricString()).Set(chas.PhysicalSecurity.IntrusionSensor.ToIntrusion());
                    }
                    if (chas.PowerLookUp != null)
                    {
                        var name = chas.PowerLookUp.Id ?? chas.PowerLookUp.Name;
                        foreach (var pow in chas.PowerLookUp.PowerControl)
                        {
                            //var nam = Helper.createId(pow.Id,pow.Name);
                            var status = pow.Status.ToMetric();
                            _chassis_power_control_health.Labels(chas.Id, pow.Name.ToMetric(), pow.Id.ToMetric()).Set(status.HealthVal);
                            _chassis_power_control_state.Labels(chas.Id, pow.Name.ToMetric(), pow.Id.ToMetric()).Set(status.StateMetric);
                            if (pow.PowerMetrics != null)
                            {
                                var consumed = pow.PowerConsumedWatts.HasValue ? pow.PowerConsumedWatts.ToMetric() : pow.PowerMetrics.PowerConsumedWatts.ToMetric();
                                _chassis_power_control_consumed_watts.Labels(chas.Id, pow.Name.ToMetric(), pow.Id.ToMetric()).Set(consumed);
                                _chassis_power_control_avg_consumed_watts.Labels(chas.Id, pow.Name.ToMetric(), pow.Id.ToMetric(), pow.PowerMetrics.IntervalInMin.ToMetricString())
                                        .Set(pow.PowerMetrics.AverageConsumedWatts.ToMetric());
                                _chassis_power_control_min_consumed_watts.Labels(chas.Id, pow.Name.ToMetric(), pow.Id.ToMetric(), pow.PowerMetrics.IntervalInMin.ToMetricString())
                                        .Set(pow.PowerMetrics.MinConsumedWatts.ToMetric());
                                _chassis_power_control_max_consumed_watts.Labels(chas.Id, pow.Name.ToMetric(), pow.Id.ToMetric(), pow.PowerMetrics.IntervalInMin.ToMetricString())
                                       .Set(pow.PowerMetrics.MaxConsumedWatts.ToMetric());
                            }
                        }
                        foreach (var vol in chas.PowerLookUp.Voltages)
                        {
                            var rel = vol.RelatedItem != null ? String.Join(", ", vol.RelatedItem.Select(it => it.OdataId.ToMetric())) : "";
                            //var nam = Helper.createId(vol.Id, vol.Name);
                            var status = vol.Status.ToMetric();
                            _chassis_voltage_health.Labels(chas.Id, vol.Name.ToMetric(), vol.Id.ToMetric(), vol.PhysicalContext.ToMetric(), rel).Set(status.HealthVal);
                            _chassis_voltage_state.Labels(chas.Id, vol.Name.ToMetric(), vol.Id.ToMetric(), vol.PhysicalContext.ToMetric(), rel).Set(status.StateMetric);
                            _chassis_voltage_reading.Labels(chas.Id, vol.Name.ToMetric(), vol.Id.ToMetric()).Set(vol.ReadingVolts.ToMetric());
                            _chassis_voltage_reading_critical_low.Labels(chas.Id, vol.Name.ToMetric(), vol.Id.ToMetric()).Set(vol.LowerThresholdCritical.ToMetric());
                            _chassis_voltage_reading_fatal_low.Labels(chas.Id, vol.Name.ToMetric(), vol.Id.ToMetric()).Set(vol.LowerThresholdFatal.ToMetric());
                            _chassis_voltage_reading_critical_up.Labels(chas.Id, vol.Name.ToMetric(), vol.Id.ToMetric()).Set(vol.UpperThresholdCritical.ToMetric());
                            _chassis_voltage_reading_fatal_up.Labels(chas.Id, vol.Name.ToMetric(), vol.Id.ToMetric()).Set(vol.UpperThresholdFatal.ToMetric());
                        }
                        foreach (var sup in chas.PowerLookUp.PowerSupplies)
                        {
                            //var nam = Helper.createId(vol.Id,vol.Name);
                            var status = sup.Status.ToMetric();
                            _chassis_power_supplies_health.Labels(chas.Id, sup.Name.ToMetric(), sup.Id.ToMetric()).Set(status.HealthVal);
                            _chassis_power_supplies_state.Labels(chas.Id, sup.Name.ToMetric(), sup.Id.ToMetric()).Set(status.StateMetric);

                            var maxVol = "";
                            var minVol = "";
                            if (sup.InputRanges != null && sup.InputRanges.Count > 0)
                            {
                                maxVol = String.Join(", ", sup.InputRanges.Select(item => item.MaximumVoltage.ToMetricString()));
                                minVol = String.Join(", ", sup.InputRanges.Select(item => item.MaximumVoltage.ToMetricString()));
                            }
                            _chassis_power_supplies_input_voltage.Labels(chas.Id, sup.Name.ToMetric(), sup.Id.ToMetric(), minVol, maxVol).Set(sup.LineInputVoltage.ToMetric());
                        }
                        foreach (var red in chas.PowerLookUp.Redundancy)
                        {
                            var redun = String.Join(", ", red.RedundancySet.Select(it => it.OdataId.ToMetric()));
                            _chassis_power_redundancy.Labels(chas.Id, red.Mode.ToMetric(), redun).Set((red.RedundancySet.Count > 0) == true ? 1 : 0);
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception during creating chassis power metric: " + e.Message);
                }
                try { 
                    if (chas.ThermalLookUp != null)
                    {
                        if (chas.ThermalLookUp.Temperatures.Count > 0)
                        {
                            foreach (var temp in chas.ThermalLookUp.Temperatures)
                            {
                                var rel = temp.RelatedItem!=null? String.Join(", ", temp.RelatedItem.Select(it => it.OdataId.ToMetric())):"";
                                var status = temp.Status.ToMetric();
                                //var nam = Helper.createId(temp.Name, temp.Id);
                                _chassis_temp_health.Labels(chas.Id, temp.Name.ToMetric(), temp.Id.ToMetric(), temp.PhysicalContext.ToMetric(), rel).Set(status.HealthVal);
                                _chassis_temp_state.Labels(chas.Id, temp.Name.ToMetric(), temp.Id.ToMetric(), temp.PhysicalContext.ToMetric(), rel).Set(status.StateMetric);
                                _chassis_temp.Labels(chas.Id, temp.Name.ToMetric(), temp.Id.ToMetric()).Set(temp.ReadingCelsius.ToMetric());
                                _chassis_temp_critical_low.Labels(chas.Id, temp.Name.ToMetric(), temp.Id.ToMetric()).Set(temp.LowerThresholdCritical.ToMetric());
                                _chassis_temp_fatal_low.Labels(chas.Id, temp.Name.ToMetric(), temp.Id.ToMetric()).Set(temp.LowerThresholdFatal.ToMetric());
                                _chassis_temp_critical_up.Labels(chas.Id, temp.Name.ToMetric(), temp.Id.ToMetric()).Set(temp.UpperThresholdCritical.ToMetric());
                                _chassis_temp_fatal_up.Labels(chas.Id, temp.Name.ToMetric(), temp.Id.ToMetric()).Set(temp.UpperThresholdFatal.ToMetric());
                            }
                        }
                        if (chas.ThermalLookUp.Fans.Count > 0)
                        {
                            foreach (var fan in chas.ThermalLookUp.Fans)
                            {
                                var rel = fan.RelatedItem!=null ? String.Join(", ", fan.RelatedItem.Select(it => it.OdataId.ToMetric())): "";
                                var status = fan.Status.ToMetric(); 
                                _chassis_fan_health.Labels(chas.Id, fan.Name.ToMetric(), fan.Id.ToMetric(), rel).Set(status.HealthVal);
                                _chassis_fan_state.Labels(chas.Id, fan.Name.ToMetric(), fan.Id.ToMetric(), rel).Set(status.StateMetric);
                                _chassis_fan_reading.Labels(chas.Id, fan.Name.ToMetric(), fan.Id.ToMetric()).Set(fan.Reading.ToMetric());
                                _chassis_fan_reading_critical_low.Labels(chas.Id, fan.Name.ToMetric(), fan.Id.ToMetric()).Set(fan.LowerThresholdCritical.ToMetric());
                                _chassis_fan_reading_fatal_low.Labels(chas.Id, fan.Name.ToMetric(), fan.Id.ToMetric()).Set(fan.LowerThresholdFatal.ToMetric());
                                _chassis_fan_reading_critical_up.Labels(chas.Id, fan.Name.ToMetric(), fan.Id.ToMetric()).Set(fan.UpperThresholdCritical.ToMetric());
                                _chassis_fan_reading_fatal_up.Labels(chas.Id, fan.Name.ToMetric(), fan.Id.ToMetric()).Set(fan.UpperThresholdFatal.ToMetric());
                                    
                            }

                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception during creating chassis thermal (temperature and fans) metric: " + e.Message);
                }
            }
   
        }

        public void Systems(List<Systems> systems)
        {
            foreach (var sys in systems)
            {
                try
                {
                    var status = sys.Status.ToMetric();
                    sys.HostName = sys.HostName.ToMetric();
                    sys.Id = sys.Id.ToMetric();
                    _system_health.Labels(sys.HostName, sys.Id).Set(status.HealthVal);
                    _system_state.Labels(sys.HostName, sys.Id).Set(status.StateMetric);
                    _system_power_state.Labels(sys.HostName, sys.Id, sys.SystemType.ToMetric(), sys.PowerState.ToMetric()).Set(sys.PowerState.IsOn());

                    status = sys.MemorySummary != null ? sys.MemorySummary.Status.ToMetric() : new Status();
                    _system_memories_health.Labels(sys.HostName, sys.Id, sys.MemorySummary.Model.ToMetric(), sys.MemorySummary.TotalSystemMemoryGiB.ToMetricString()).Set(status.HealthVal);
                    _system_memories_state.Labels(sys.HostName, sys.Id, sys.MemorySummary.Model.ToMetric(),sys.MemorySummary.TotalSystemMemoryGiB.ToMetricString()).Set(status.StateMetric);

                    status = sys.ProcessorSummary!=null? sys.ProcessorSummary.Status.ToMetric(): new Status();
                    _system_processors_health.Labels(sys.HostName, sys.Id, sys.ProcessorSummary.Model).Set(status.HealthVal);
                    _system_processors_state.Labels(sys.HostName, sys.Id, sys.ProcessorSummary.Model).Set(status.StateMetric);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception during creating system general (health, power state, processor, memory) metric: " + e.Message);
                }
                try
                {
                    foreach (var proc in sys.ProcessorsLookUp.CPULookUp)
                    {
                        var status = proc.Status.ToMetric();
                        _system_processor_health.Labels(sys.HostName, sys.Id, proc.Id, proc.ProcessorType).Set(status.HealthVal);
                        _system_processor_state.Labels(sys.HostName, sys.Id, proc.Id, proc.ProcessorType).Set(status.StateMetric);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception during creating system processors metric: " + e.Message);
                }
                try
                {
                    if (sys.EthernetInterfacesLookUp != null)
                    {
                        foreach (var eth in sys.EthernetInterfacesLookUp.EthernetInterfacesUnitLookUp)
                        {
                            var mac = Helper.createId(eth.PermanentMACAddress, eth.MACAddress);
                            var name = Helper.createId(eth.FQDN, eth.HostName);
                            var ip = String.Join(", ", eth.IPv4Addresses.Select(it => it.Address.ToMetric()));
                            var status = eth.Status.ToMetric();
                            eth.Id = eth.Id.ToMetric();

                            _system_ethernet_interface_health.Labels(sys.HostName, sys.Id, eth.Id, mac).Set(status.HealthVal);
                            _system_ethernet_interface_state.Labels(sys.HostName, sys.Id, eth.Id, mac).Set(status.StateMetric);
                            _system_ethernet_interface_speed.Labels(sys.HostName, sys.Id, eth.Id, ip, eth.AutoNeg.ToMetricString(),
                                eth.FullDuplex.ToMetricString(), eth.MTUSize.ToMetricString()).Set(eth.SpeedMbps.ToMetric());
                            if (eth.VLAN != null)
                                _system_ethernet_interface_vlan.Labels(sys.HostName, sys.Id, eth.Id, eth.VLAN.VLANId.ToMetricString(),
                                    eth.VLAN.Name.ToMetric()).Set(eth.VLAN.VLANEnable.ToMetric());
                            if (eth.VLANsLookup != null)
                            {
                                foreach (var vlan in eth.VLANsLookup.VLANsUnitLookUp)
                                {
                                    _system_ethernet_interface_vlan.Labels(sys.HostName, sys.Id, eth.Id, vlan.VLANId.ToMetricString(),
                                        vlan.Name.ToMetric()).Set(vlan.VLANEnable.ToMetric());
                                }
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception during creating system ethernet interfaces metric: " + e.Message);
                }
                //storage
                if (sys.StorageLookUp != null)
                {
                    //todo
                }
                //storage
                if (sys.SimpleStorageLookUp != null)
                {
                    foreach (var stor in sys.SimpleStorageLookUp.SimpleStorageUnitLookUp)
                    {
                        var status = stor.Status.ToMetric();
                        var name = stor.Name.ToMetric();
                        sys.Id = sys.Id.ToMetric();
                        _system_simplestorage_health.Labels(sys.HostName, sys.Id, name).Set(status.HealthVal);
                        _system_simplestorage_state.Labels(sys.HostName, sys.Id, name).Set(status.StateMetric);
                    }
                }

                try
                {
                    if (sys.Oem?.Hp != null)
                    {
                        var stor = sys.Oem.Hp;
                        sys.HostName = sys.HostName.ToMetric();
                        sys.Id = sys.Id.ToMetric();

                        if (stor.Batteries != null)
                        {
                            foreach (var bat in stor.Batteries)
                            {
                                _system_storage_battery_health.Labels(sys.HostName, sys.Id, bat.ErrorCode.ToMetricString(),
                                    bat.Index.ToMetricString(), bat.Present.ToMetric(), bat.Condition.ToMetric())
                                    .Set(bat.Condition.IsOk());
                            }
                        }
                        if (stor.SmartStorageLookup != null)
                        {
                            var op = Helper.createId(stor.HostOS?.OsName, stor.HostOS.OsName);
                            var status = stor.SmartStorageLookup.Status.ToMetric();
                            _system_storage_health.Labels(sys.HostName, sys.Id, op).Set(status.HealthVal);
                            _system_storage_state.Labels(sys.HostName, sys.Id, op).Set(status.StateMetric);
                            if (stor.SmartStorageLookup.ArrayControllers != null)
                            {
                                foreach (var ac in stor.SmartStorageLookup.ArrayControllers.ArrayControllersUnitLookup)
                                {
                                    ac.Id = ac.Id.ToMetric();
                                    status = ac.Status.ToMetric();
                                    _system_storage_array_ctrl_health.Labels(sys.HostName, sys.Id, ac.Id, ac.BackupPowerSourceStatus.ToMetric(),
                                        ac.CurrentOperatingMode.ToMetric()).Set(status.HealthVal);
                                    _system_storage_array_ctrl_state.Labels(sys.HostName, sys.Id, ac.Id, ac.BackupPowerSourceStatus.ToMetric(),
                                        ac.CurrentOperatingMode.ToMetric()).Set(status.StateMetric);

                                    if (ac.LogicalDrivesLookUp != null)
                                    {
                                        foreach (var ld in ac.LogicalDrivesLookUp.LogicalDrivesUnitLookUp)
                                        {
                                            status = ld.Status.ToMetric();
                                            _system_storage_logical_drive_health.Labels(sys.HostName, sys.Id, ac.Id, ld.Id.ToMetric(), 
                                                ld.LogicalDriveNumber.ToMetricString(), ld.LogicalDriveType.ToMetric(), ld.Raid.ToMetricString()).Set(status.HealthVal);
                                            _system_storage_logical_drive_state.Labels(sys.HostName, sys.Id, ac.Id, ld.Id.ToMetric(),
                                                ld.LogicalDriveNumber.ToMetricString(), ld.LogicalDriveType.ToMetric(), ld.Raid.ToMetricString()).Set(status.StateMetric);
                                        }
                                    }

                                    if (ac.DiskDrivesLookUp != null)
                                    {
                                        foreach (var dd in ac.DiskDrivesLookUp.DiskDrivesUnitLookUp)
                                        {
                                            status = dd.Status.ToMetric();
                                            dd.Name = dd.Name.ToMetric();
                                            _system_storage_disk_drive_health.Labels(sys.HostName, sys.Id, ac.Id, dd.Name, String.Join(", ", dd.DiskDriveStatusReasons)).Set(status.HealthVal);
                                            _system_storage_disk_drive_state.Labels(sys.HostName, sys.Id, ac.Id, dd.Name, String.Join(", ", dd.DiskDriveStatusReasons)).Set(status.StateMetric);
                                            _system_storage_disk_drive_temperature.Labels(sys.HostName, sys.Id, ac.Id, dd.Name).Set(dd.CurrentTemperatureCelsius.ToMetric());
                                            _system_storage_disk_drive_temperature_max.Labels(sys.HostName, sys.Id, ac.Id, dd.Name).Set(dd.MaximumTemperatureCelsius.ToMetric());
                                            _system_storage_ssd_endurance_utilization.Labels(sys.HostName, sys.Id, ac.Id, dd.Name)
                                                .Set(dd.SSDEnduranceUtilizationPercentage.ToMetric());
                                            _system_storage_carrier_authentication_status.Labels(sys.HostName, sys.Id, ac.Id, dd.Name)
                                                .Set(dd.CarrierAuthenticationStatus.IsOk());
                                            if (dd.MediaType == "HDD")
                                                _system_storage_rotational_speed_rpm.Labels(sys.HostName, sys.Id, ac.Id, dd.Name, dd.MediaType.ToMetric())
                                                    .Set(dd.RotationalSpeedRpm.ToMetric());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception during creating system oem for HP metric: " + e.Message);
                }

            }
        }

        public void Managers(List<Managers> managers)
        {
            foreach (var man in managers)
            {
                try
                {
                    var status = man.Status.ToMetric();
                    _manager_health.Labels(man.Id, man.ManagerType).Set(status.HealthVal);
                    _manager_state.Labels(man.Id, man.ManagerType).Set(status.StateMetric);

                    _manager_links.Labels(man.Id, "", "").Set(0);
                    if (man.Links != null)
                    {
                        var sys = String.Join(", ", man.Links.ManagerForServers.Select(it => it.OdataId.Replace("/redfish/v1/Systems/","").ToMetric()));
                        var chas = String.Join(", ", man.Links.ManagerForChassis.Select(it => it.OdataId.Replace("/redfish/v1/Chassis/", "").ToMetric()));
                        if (!string.IsNullOrEmpty(sys) || !string.IsNullOrEmpty(chas)) _manager_links.Labels(man.Id, sys, chas).Set(1);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception during creating managers general (status, links) metric: " + e.Message);
                }
                try
                {
                    if (man.EthernetInterfacesLookUp != null)
                    {
                        foreach (var eth in man.EthernetInterfacesLookUp.Items)
                        {
                            var mac = Helper.createId(eth.FactoryMacAddress, eth.MacAddress);
                            var host = Helper.createId(eth.FQDN, eth.HostName);
                            var autoneg = !string.IsNullOrEmpty(eth.Autoneg) ? eth.Autoneg : eth.AutoSense;
                            
                            _manager_eth_interface_speed.Labels(man.Id, eth.Id, mac, host, autoneg.ToMetric(), eth.Fullduplex.ToMetric()).Set(eth.SpeedMbps);
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception during creating managers ethernet interfaces metric: " + e.Message);
                }
            }
        }
    }
}

