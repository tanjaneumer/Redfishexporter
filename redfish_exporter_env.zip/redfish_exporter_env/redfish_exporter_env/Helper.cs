﻿using redfish_exporter_env.RedfishPocos;
using System;
using System.Collections.Generic;
using System.Text;

namespace redfish_exporter_env
{
    public static class Helper
    {
        public static Status ToMetric(this Status stat)
        {
            if (stat == null) return new Status();
            stat.State = stat.State ?? "";
            stat.Health = stat.Health ?? "";
            stat.HealthRollup = stat.HealthRollup ?? "";

            return stat;
        }

        public static double ToMetric(this double? val)
        {
            if (val.HasValue) return val.Value;
            return -9999;
        }
        public static string ToMetricString(this double? val)
        {
            if (val.HasValue) return val.Value.ToString();
            return "unknown";
        }
        public static string ToMetric(this string str)
        {
            if (!string.IsNullOrEmpty(str)) return str;
            return "unknown";
        }
        public static string ToMetricString(this bool? val)
        {
            if (val.HasValue) return val.Value.ToString();
            return "unknown";
        }
        public static double ToMetric(this bool? val)
        {
            if (!val.HasValue) return -1;
            if (val.Value) return 1;
            return 0;
        }
        public static string createId(string id, string name)
        {
            return !string.IsNullOrEmpty(id) ? id : (name ?? "");
        }
        public static double IsOn(this string str)
        {
            if (string.IsNullOrEmpty(str)) return -1;
            if (str.ToLower() == "on") return 1;
            return 0;
        }
        public static double IsOk(this string str)
        {
            if (string.IsNullOrEmpty(str)) return -1;
            if (str.ToLower() == "ok") return 1;
            return 0;
        }
        public static double ToStatus(this string str)
        {
            //if (string.IsNullOrEmpty(str)) return -1;
            switch (str.ToLower())
            {
                case "ok":
                    return 1;
                case "warning":
                    return 0.5;
                case "critical":
                    return 0;
                default:
                    return -1;
            }
        }
        public static double ToState(this string str)
        {
            //if (string.IsNullOrEmpty(str)) return -1;
            switch (str.ToLower())
            {
                case "absent":
                    return 0;
                case "enabled":
                case "quiesced":
                    return 1;
                case "standbyspare":
                case "standbyoffline":
                    return 2;
                case "intest":
                case "starting":
                case "updating":
                    return 3;
                case "deferring":
                case "disabled":
                case "unavailableoffline":
                    return 4;
                default:
                    return -1;
            }
        }
        public static double ToIntrusion(this string str)
        {
            //if (string.IsNullOrEmpty(str)) return -1;
            switch (str.ToLower())
            {
                case "normal":
                    return 1;
                case "hardwareintrusion":
                    return 2;
                case "tamperingdetected":
                    return 3;
                default:
                    return -1;
            }
        }

        public static double IsTrue(this string str)
        {
            if (string.IsNullOrEmpty(str)) return -1;
            switch (str.ToLower())
            {
                case "true":
                    return 1;
                case "false":
                    return 0;
                default:
                    return -1;
            }
        }
    }
}